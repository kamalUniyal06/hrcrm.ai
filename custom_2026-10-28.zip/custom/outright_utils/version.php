<?php

$outright_version ='42';