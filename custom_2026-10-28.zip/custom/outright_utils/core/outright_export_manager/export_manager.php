<?php
function getModuleNameExport(){
	global $moduleList;
	global $modInvisList;
	$outright_final_mod = array_merge($moduleList,$modInvisList);
	$outright_module_lists = array();
	$cust_mod_path ="custom/modules/*";
$custom_modules = array_filter(glob($cust_mod_path), 'is_dir');
foreach($custom_modules as $custom_module){
$cust_path[$custom_module] = $custom_module;
}
	foreach( $outright_final_mod as $outright_module_list ){
		$mod_name = " ".$outright_module_list;
		if( strpos( $mod_name , 'outr'  ) && !$_REQUEST['all_modules'] ){
		  	$outright_module_lists[$outright_module_list]  = $outright_module_list;
		}
		else if( $_REQUEST['all_modules'] ){
		$outright_module_lists[$outright_module_list]  = $outright_module_list;
		}	
	}
	$final_array = array_merge( $outright_module_lists ,$cust_path);
   return array_unique($final_array);
}

function get_custom_fields_for_any_module($mod){
	$outright_sql = "SELECT * FROM fields_meta_data where custom_module = '".$mod."' and deleted = 0";
	$res = outright_run_sql($outright_sql);
	return $res;
	
}
