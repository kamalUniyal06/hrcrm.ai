<?php

/*****************************************
 * 
 *      @description  : outright_set_get_trello save and update bean  
 *      @since 40.0.0
 * 
 * ***************************************/

function outright_set_get($data_obj = false, $bean_name = false, $save_me = '0')
{
    if (is_array($data_obj)) {
        $data_obj = (object) $data_obj;
    }
    if (is_string($data_obj)) {
        $bean_id = $data_obj;
    } else {
        $bean_id = $data_obj->id;
    }
    $sql = "update " . strtolower($bean_name) . " set deleted =0 where id ='" . $bean_id . "' and deleted =1 ";
    outright_run_sql($sql);

    if ($bean_id && !$data_obj->new_with_id) {
        $ret_bean = outright_retrieve($bean_name, $bean_id);
        if (!$ret_bean->id) {
            $ret_bean = outright_retrieve($bean_name);
            $ret_bean->id = $bean_id;
            $ret_bean->new_with_id = 1;
        }
    } else {
        $ret_bean = outright_retrieve($bean_name);
    }

    if ($save_me) {
        foreach ($data_obj as $field => $value) {
            if (!is_object($value) && !is_array($value)) {
                $ret_bean->$field = $value;
            }
        }
        $ret_bean->save();
    }
    return $ret_bean;
}

/*****************************************
 * 
 *      @description  : Array To String Conversion  
 *      @Author       : Outright 
 *      @Date         : 
 *      @param   array        ---> $input_arr  :  array value to convert into string  
 *      @return  string|false ---> $return_str :  Return's the string on success or false on fail      
 *      @since 1.0.0
 * 
 * ***************************************/
function outright_array_to_sql($input_arr)
{
    if (!is_array($input_arr)) {
        return false;
    }
    $return_str = "'" . implode("','", $input_arr) . "'";
    return $return_str;
}

/*****************************************
 * 
 *     @description : Enum to array convertion
 *     @Author      : Outright 
 *     Date         :  
 *     @param     string --->$enum_string      : Enum string;       
 *     @param     string --->$enum_string_js   : Enum js string;              
 *     @return    array|false --->$enum_string_js : Return's the enum_string_js array on success or false on fail  ;    
 *     @since 1.0.0
 * 
 * ***************************************/

function outright_convert_enum_to_array($enum_string, $enum_string_js)
{
    $final_ret_array = array();
    $enum_string = str_replace('^', "", $enum_string);
    $final_ret_array = explode(',', $enum_string);
    $enum_string_js = str_replace('^', "#", $enum_string_js);
    $enum_string_js = str_replace('#,', ",", $enum_string_js);
    $final_ret_array['enum_js'] = substr($enum_string_js, 0, -1);
    return $final_ret_array ? $enum_string_js : false;
}

/*****************************************
 * 
 *     @description : option to array convert 
 *     @Author      : Outright 
 *     Date         :  
 *     @param     string --->$sql           : mysql query value                                                           
 *     @param     string --->$key_col       : colomn key value                                                                
 *     @param     string --->$val_col       : value  of the colomn                                                                
 *     @return    string|false --->$option  : Returns string value on success or false in fail                                                             
 *     @since 1.0.0
 * 
 * ***************************************/

function outright_convert_options_from_sql($sql, $key_col, $val_col, $selected = false)
{
    $options_array = outright_run_id_name_sql($sql, $key_col, $val_col, $selected);
    $option = outright_convert_options_from_array($options_array, $selected);
    return $option ? $option : false;
}

/*****************************************
 * 
 *     @description  : Array to html drop down convert 
 *     @Author       : Outright 
 *     @Date         :  
 *     @param       array--->$optionArr : options array;
 *     @param       int|string--->$selected : selected value for drop down list ;
 *     @return  string|false ---> $option :  Return's the string on success or false on fail  ;    
 *     @since 1.0.0
 * 
 * ***************************************/

function outright_convert_options_from_array($optionArr, $selected)
{
    foreach ($optionArr as $key => $values) {
        $sel = '';
        if ($key == $selected) {
            $sel = "selected";
        }
        $option .= "<option value='" . $key . "' " . $sel . " >" . $values . "</option>";
    }
    return $option ? $option : false;
}
/*****************************************
 * 
 *     @description : Get colomns from table
 *     @Author      : Outright 
 *     Date         :  
 *     @param     string --->$table       : table name                                                          
 *     @return    array  : Returns array value on success 
 *     @since 1.0.0
 * 
 * ***************************************/

function outright_getcolumns($table)
{
    global $db;
    $sql = "SHOW columns FROM " . $table;
    $rwo = $db->query($sql);
    $ar = array();
    $matchcols = array();
    $i = 0;
    while ($res = $db->fetchByAssoc($rwo)) {
        $matchcols[] = $res['Field'];
        $ar[$i] = array('fname' => $res['Field'], 'ftype' => $res['Type']);
        $i++;
    }
    return array('cols' => $matchcols, 'detail' => $ar);
}

/*****************************************
 * 
 *     @description : Get user details
 *     @Author      : Outright 
 *     Date         :  
 *     @param     string --->$userID      : user id                                                              
 *     @return    obj|false  : Returns Obj value on success or false on fail
 *     @since 1.0.0
 * 
 * ***************************************/

function outright_load_user($userID)
{
    $user_bean = new User();
    $user_bean->retrieve($userID);
    return $user_bean ? $user_bean : false;
}

/*********************
 *start outright_load
 * @description : Get user details
 * @Author      : Outright Systems
 * Date         :  
 * @param     string --->$userID      : user id                                                              
 * @return    obj|false  : Returns Obj value on success or false on fail
 * @since 1.0.0
 ******************/
function outright_run_id_name_sql($sql, $field1, $field2, $ret_str = 0)
{
    global $db;
    $fin_res = array();
    $retrun_str = '';
    $row = $db->query($sql);
    while ($res = $db->fetchByAssoc($row)) {
        $fin_res[$res[$field1]] = $res[$field2];
    }

    if ($ret_str) {
        return outright_array_to_sql_string($fin_res);
    }
    return $fin_res;
}

function outright_get_custom_fields($mod)
{
    $outright_sql = "SELECT * FROM fields_meta_data where custom_module = '" . $mod . "' and deleted = 0";
    $res = outright_run_sql($outright_sql);
    return $res;
}

function outright_get_module_fields($module_name = NULL)
{
    global $app_list_strings;
    if ($module_name) {
        $fieldArr = outiright_return_ModuleFields($module_name);
        unset($fieldArr['id']);
        return $fieldArr;
    } else {
        $fieldArr = array();
        $moduleList = outright_getModuleName_list();
        foreach ($moduleList as $key => $values) {
            if ($values) {
                $fieldArr[$key] = outiright_return_ModuleFields($values);
            }
        }
        unset($fieldArr['id']);
        return $fieldArr;
    }
}


function outright_built_config(array $configOptions = null, $config_loader = true, $dieOnError = false)
{
    global $sugar_config;
    if (is_null($configOptions)) {
        $configOptions = $sugar_config;
    }
    if ($config_loader) {
        if (!file_exists('config.php')) {
            require_once('config_outright.php');
        }
        if (file_exists('config.php')) {
            require_once('config.php');
        }
    }
    if ($sugar_config == false && !isset($sugar_config) && empty($sugar_config)) {

        $connect_error[] = "Error has been occured while creatiing a config file . Please refer to outrightcrm.log for details.";
        $err_msg[] = "Unable to load the data from config_outright.php(or)config.php file please check your directory structure file is existed or not.";
        if (!$GLOBALS['log']->fatal($err_msg)) {
            outrigt_error_log($this->logfile, $err_msg);
        }
        if ($dieOnError) {
            if (isset($GLOBALS['app_strings']['ERR_NO_DB'])) {
                outright_die($GLOBALS['app_strings']['ERR_NO_DB']);
            } else {
                outright_die("Unable to load the data from config_outright.php(or)config.php file please check your directory structure file is existed or not.");
            }
        }
        $_SESSION['outright_errors'] = $connect_error;
        return false;
    }
    $sugar_config['installer_locked'] = true;
    $sugar_config['dbconfig']['db_host_name'] = $configOptions['db_host_name'];
    $sugar_config['dbconfig']['db_user_name'] = $configOptions['db_user_name'];
    $sugar_config['dbconfig']['db_password'] = $configOptions['db_password'];
    $sugar_config['dbconfig']['db_name'] = $configOptions['db_name'];
    $sugar_config['site_url'] = $configOptions['site_url'];
    $build_config = outright_array_to_file_write('sugar_config', $sugar_config, 'config.php', $mode = "w", $header = '');
    if ($build_config)
        return true;
}
function outright_get_correct_bean($mod_name)
{
    global $beanFiles;

    $new_bean = BeanFactory::newBean($mod_name);
    // last chance if bean still not retrieved
    if (!$new_bean) {
        $GLOBALS['log']->fatal("Your bean name was incorrect! Please correct it in your code" . $mod_name);
        if ($beanFiles[$mod_name]) {
            require_once $beanFiles[$mod_name];
            $new_bean = new $mod_name;
        }
    }
    return $new_bean;
}

/*****************************************
 * start outright_run_sql
 *      @description  : Fetch the data from data base and 
 *      @Author       : Outright 
 *      @Date         : 
 *      @param   string      ---> $sql :  mysql query value; 
 *      @return  array|false ---> $fin_res :  Return's the array on success or false on fail      
 *      @since 1.0.0
 * 
 * ***************************************/

function outright_run_sql($sql)
{
    global $db;

    $fin_res = array();
    $row = $db->query($sql);
    if (is_object($row)) {
        while ($res = $db->fetchByAssoc($row)) {
            $fin_res[] = $res;
        }
    }

    return $fin_res ? $fin_res : false;
}
/** End outright_run_sql**/

/*****************************************
 *start outright_run_sql_one_row 
 *      Returns the only one row from data base 
 *      @Author       : Outright 
 *      @Date         :  
 *      @param       string--->$sql : sql query value  ;
 *      @return  array|false ---> $fin_res :  Return's the array on success or false on fail      
 *      @since 1.0.0
 * 
 * ***************************************/

function outright_run_sql_one_row($sql)
{
    global $db;
    $row = $db->query($sql);
    if (is_object($row)) {
        $res = $db->fetchByAssoc($row);
    }
    return $res ? $res : false;
}
/** End outright_run_sql_one_row**/

// Json Decode function
function outright_json_decoder($data = false)
{
    if ($data == false) {
        return 'Input data empty. Please check your input string!';
    }
    if (outright_json_validator($data)) {
        return json_decode($data);
    }
}

// Json validator function
function outright_json_validator($json = false)
{
    if ($json == false) {
        return 'Input data empty. Please check your input string!';
    }
    $result = json_decode($json);
    // switch and check possible JSON errors
    switch (json_last_error()) {
        case JSON_ERROR_NONE:
            $error = ''; // No error has occurred
            break;
        case JSON_ERROR_DEPTH:
            $error = 'The maximum stack depth has been exceeded.';
            break;
        case JSON_ERROR_STATE_MISMATCH:
            $error = 'Invalid or malformed JSON.';
            break;
        case JSON_ERROR_CTRL_CHAR:
            $error = 'Control character error, possibly incorrectly encoded.';
            break;
        case JSON_ERROR_SYNTAX:
            $error = 'Syntax error, malformed JSON.';
            break;
        case JSON_ERROR_UTF8:
            $error = 'Malformed UTF-8 characters, possibly incorrectly encoded.';
            break;
        case JSON_ERROR_RECURSION:
            $error = 'One or more recursive references in the value to be encoded.';
            break;
        case JSON_ERROR_INF_OR_NAN:
            $error = 'One or more NAN or INF values in the value to be encoded.';
            break;
        case JSON_ERROR_UNSUPPORTED_TYPE:
            $error = 'A value of a type that cannot be encoded was given.';
            break;
        default:
            $error = 'Unknown JSON error occured.';
            break;
    }

    if ($error !== '') {
        exit($error);
    }

    return true;
}

// outright_multarray_to_array
function outright_multarray_to_array($mul_array, $key)
{
    $ret_array = array();
    foreach ($mul_array as $fin_arr) {
        $ret_array[] = $fin_arr[$key];
    }
    return $ret_array;
}

// outiright_modulefields_typewise in function  $fields_type=array('varchar','phone');
function outiright_modulefields_typewise($module, $fields_type)
{
    global $app_strings, $beanList;
    $fields = array();
    if (isset($beanList[$module]) && $beanList[$module]) {
        $mod = new $beanList[$module]();
        foreach ($mod->field_defs as $name => $arr) {
            if (ACLController::checkAccess($mod->module_dir, 'list', true) && in_array($arr['type'], $fields_type) && $arr['source'] != 'non-db') {
                if (isset($arr['vname']) && $arr['vname'] != '') {
                    $fields[$name] = rtrim(translate($arr['vname'], $mod->module_dir), ':');
                } else {
                    $fields[$name] = $name;
                }
            }
        }
    }
    foreach ($fields as $key => $value) {
        $fields_arr[$key] = $value;
    }
    return $fields_arr;
}

function outright_safe_count($array)
{
    if (is_array($array)) {
        return count($array);
    }
    return false;
}



function isCronTimeMatch($pattern)
{
    date_default_timezone_set('Asia/Kolkata');
    // Break the pattern into its parts
    list($min, $hour, $dom, $month, $dow) = explode('::', $pattern);

    // Get current time parts
    $now = [
        'min'   => (int) date('i'),
        'hour'  => (int) date('G'),
        'dom'   => (int) date('j'),
        'month' => (int) date('n'),
        'dow'   => (int) date('w'), // 0 (Sunday) to 6 (Saturday)
    ];

    // Match each part
    return matchCronField($min, $now['min'], 0, 59) &&
        matchCronField($hour, $now['hour'], 0, 23) &&
        matchCronField($dom, $now['dom'], 1, 31) &&
        matchCronField($month, $now['month'], 1, 12) &&
        matchCronField($dow, $now['dow'], 0, 6);
}

function matchCronField($field, $current, $min, $max)
{
    if ($field === '*') return true;

    foreach (explode(',', $field) as $part) {
        if (strpos($part, '/') !== false) {
            [$range, $step] = explode('/', $part);
            $step = (int) $step;
            $rangeStart = $min;
            $rangeEnd = $max;

            if ($range !== '*') {
                if (strpos($range, '-') !== false) {
                    [$rangeStart, $rangeEnd] = explode('-', $range);
                } else {
                    $rangeStart = $rangeEnd = $range;
                }
            }

            for ($i = $rangeStart; $i <= $rangeEnd; $i++) {
                if ($i % $step === 0 && $i == $current) return true;
            }
        } elseif (strpos($part, '-') !== false) {
            [$start, $end] = explode('-', $part);
            if ($current >= $start && $current <= $end) return true;
        } elseif ((int)$part === $current) {
            return true;
        }
    }

    return false;
}
/**
 * Generate an email-friendly HTML table that works across all email clients
 *
 * @param array $data The data to display in the table
 * @param string|false $module Module name for linking
 * @param string|false $grand_total Field name for grand total calculation
 * @param string|false $date_for Start date filter
 * @param string|false $date_end End date filter
 * @param array $styling Styling configuration for email compatibility
 * @param string|false $text_color Override text color
 * @param bool $hide_data Whether to hide the table initially
 * @param string|false $table_id Custom table ID
 * @param string|false $table_class Additional CSS classes
 * @param bool $row_buttons Whether to show row action buttons
 * @param bool $edit_remove Whether to show edit/remove buttons
 * @param string|false $key Custom key field
 * @return string Generated HTML table optimized for email
 */
function generateEmailFriendlyTable(
    array $data,
    $module = false,
    $grand_total = false,
    $date_for = false,
    $date_end = false,
    array $styling = [],
    $text_color = false,
    $hide_data = false,
    $table_id = false,
    $table_class = false,
    $row_buttons = false,
    $edit_remove = false,
    $key = false
) {
    // Email-safe configuration
    $config = [
        'sugar_url' => $GLOBALS['sugar_config']['site_url'] ?? '',
        'email_safe_colors' => [
            'header_bg' => '#4A90E2',
            'header_text' => '#FFFFFF',
            'even_row_bg' => '#F8F9FA',
            'odd_row_bg' => '#FFFFFF',
            'text_color' => '#333333',
            'border_color' => '#DDDDDD',
            'link_color' => '#0066CC',
            'total_bg' => '#E8F4FD',
            'total_text' => '#2C3E50'
        ],
        'skip_columns' => ['id', 'envelopeId'],
        'linkable_fields' => ['id', 'first_name', 'name', 'document_name']
    ];

    // Merge with custom styling
    $colors = array_merge($config['email_safe_colors'], $styling);

    // Normalize data
    if (!isset($data[0]) || !is_array($data[0])) {
        $data = [$data];
    }

    if (empty($data) || empty($data[0])) {
        return generateEmailEmptyMessage($colors);
    }

    // Build email-safe table
    $html = buildEmailTableHeader(count($data), $colors, $table_id);
    $html .= buildEmailColumnHeaders($data[0], $config['skip_columns'], $colors);
    $html .= buildEmailTableBody($data, $config, $colors, $module);
    $html .= buildEmailTableFooter();

    // Add grand total if requested
    if ($grand_total && $module) {
        $html .= buildEmailGrandTotal($grand_total, $module, $date_for, $date_end, $colors);
    }

    return $html;
}

/**
 * Generate email-safe empty message
 */
function generateEmailEmptyMessage(array $colors): string
{
    return '<table id="outright_ui_table" width="100%" cellpadding="20" cellspacing="0" border="0" style="background-color: ' . $colors['total_bg'] . '; border: 1px solid ' . $colors['border_color'] . ';">
                <tr>
                    <td style="text-align: center; color: ' . $colors['total_text'] . '; font-family: Arial, sans-serif; font-size: 16px;">
                        <strong>No Data Available</strong><br>
                        There are no records to display at this time.
                    </td>
                </tr>
            </table>';
}

/**
 * Build email-safe table header
 */
function buildEmailTableHeader(int $recordCount, array $colors, $tableId): string
{
    $idAttr = $tableId ? 'id="' . $tableId . '"' : '';

    return '
    <!-- Total Records Header -->
    <table width="100%" cellpadding="15" cellspacing="0" border="0" style="background-color: ' . $colors['total_bg'] . '; border: 1px solid ' . $colors['border_color'] . '; margin-bottom: 5px; font-family: Arial, sans-serif;">
        <tr>
            <td style="text-align: center; color: ' . $colors['total_text'] . '; font-size: 16px; font-weight: bold;">
                📊 Total Records: ' . $recordCount . '
            </td>
        </tr>
    </table>
    
    <!-- Main Data Table -->
    <table ' . $idAttr . ' width="100%" cellpadding="8" cellspacing="0" border="1" style="border-collapse: collapse; border: 2px solid ' . $colors['border_color'] . '; font-family: Arial, sans-serif; font-size: 14px;">';
}

/**
 * Build email-safe column headers
 */
function buildEmailColumnHeaders(array $firstRow, array $skipColumns, array $colors): string
{
    $html = '<thead>
                <tr style="background-color: ' . $colors['header_bg'] . ';">
                    <th style="padding: 12px 8px; text-align: center; color: ' . $colors['header_text'] . '; font-weight: bold; border: 1px solid ' . $colors['border_color'] . ';">
                        Sr.No
                    </th>';

    foreach (array_keys($firstRow) as $field) {
        if (in_array($field, $skipColumns)) {
            continue;
        }

        $displayName = formatEmailFieldName($field);
        $html .= '<th style="padding: 12px 8px; text-align: center; color: ' . $colors['header_text'] . '; font-weight: bold; border: 1px solid ' . $colors['border_color'] . ';">
                    ' . $displayName . '
                  </th>';
    }

    return $html . '</tr></thead>';
}

/**
 * Build email-safe table body
 */
function buildEmailTableBody(array $data, array $config, array $colors, $module): string
{
    $html = '<tbody>';

    foreach ($data as $index => $row) {
        $serialNumber = $index + 1;
        $rowBg = ($index % 2 == 0) ? $colors['even_row_bg'] : $colors['odd_row_bg'];

        $html .= '<tr style="background-color: ' . $rowBg . ';">
                    <td style="padding: 10px 8px; text-align: center; color: ' . $colors['text_color'] . '; font-weight: bold; border: 1px solid ' . $colors['border_color'] . ';">
                        ' . $serialNumber . '
                    </td>';

        foreach ($row as $field => $value) {
            if (in_array($field, $config['skip_columns'])) {
                continue;
            }

            $cellContent = formatEmailCellValue($field, $value, $row, $config, $colors, $module);
            $html .= '<td style="padding: 10px 8px; text-align: center; color: ' . $colors['text_color'] . '; border: 1px solid ' . $colors['border_color'] . ';">
                        ' . $cellContent . '
                      </td>';
        }

        $html .= '</tr>';
    }

    return $html . '</tbody>';
}

/**
 * Build email-safe table footer
 */
function buildEmailTableFooter(): string
{
    return '</table>';
}

/**
 * Format field names for email display
 */
function formatEmailFieldName(string $field): string
{
    $formatted = str_replace(['_', '-'], ' ', $field);
    return ucwords($formatted);
}

/**
 * Format cell values for email compatibility
 */
function formatEmailCellValue(string $field, $value, array $row, array $config, array $colors, $module): string
{
    // Handle linkable fields
    if (in_array($field, $config['linkable_fields']) && $module && isset($row['id'])) {
        $url = $config['sugar_url'] . "/index.php?action=DetailView&module={$module}&record={$row['id']}";
        return '<a href="' . $url . '" style="color: ' . $colors['link_color'] . '; text-decoration: underline;" target="_blank">' . htmlspecialchars($value) . '</a>';
    }

    // Handle external links
    if ($field === 'link' && filter_var($value, FILTER_VALIDATE_URL)) {
        return '<a href="' . $value . '" style="color: ' . $colors['link_color'] . '; text-decoration: underline;" target="_blank">🔗 Click Here</a>';
    }

    // Handle dates
    if (strtotime($value) && preg_match('/\d{4}-\d{2}-\d{2}/', $value)) {
        return date('M j, Y', strtotime($value));
    }

    // Handle numbers
    if (is_numeric($value) && $value != (int)$value) {
        return number_format((float)$value, 2);
    }

    return htmlspecialchars($value ?? '');
}

/**
 * Build email-safe grand total section
 */
function buildEmailGrandTotal(string $grandTotalField, string $module, $dateFor, $dateEnd, array $colors): string
{
    $sql = buildGrandTotalQuery($grandTotalField, $module, $dateFor, $dateEnd);

    if (!$sql) {
        return '';
    }

    $result = outright_run_sql_one_row($sql);
    $fieldLabel = formatEmailFieldName($grandTotalField);
    $total = number_format($result['Count'] ?? 0, 2);

    return '<br>
            <table width="100%" cellpadding="15" cellspacing="0" border="0" style="background-color: ' . $colors['total_bg'] . '; border: 2px solid ' . $colors['header_bg'] . '; margin-top: 10px; font-family: Arial, sans-serif;">
                <tr>
                    <td style="text-align: center; color: ' . $colors['total_text'] . '; font-size: 16px; font-weight: bold;">
                        📊 Grand Total of ' . $fieldLabel . ': ' . $total . '
                    </td>
                </tr>
            </table>';
}

// Updated main function for email compatibility
function outright_html_table_new($data, $module = false, $grand_total = false, $date_for = false, $date_end = false, $row_colors = array('even' => '#F8F9FA', 'odd' => '#FFFFFF', 'text_color' => '#333333'), $text_color = false, $hide_data = false, $table_id = false, $table_class = false, $row_buttons = false, $edit_remove = false, $key = false)
{
    // Convert old color format to new format
    $emailColors = [
        'even_row_bg' => $row_colors['even'] ?? '#F8F9FA',
        'odd_row_bg' => $row_colors['odd'] ?? '#FFFFFF',
        'text_color' => $text_color ?: ($row_colors['text_color'] ?? '#333333'),
        'header_bg' => '#4A90E2',
        'header_text' => '#FFFFFF',
        'border_color' => '#DDDDDD',
        'link_color' => '#0066CC',
        'total_bg' => '#E8F4FD',
        'total_text' => '#2C3E50'
    ];
    return generateEmailFriendlyTable(
        $data,
        $module,
        $grand_total,
        $date_for,
        $date_end,
        $emailColors,
        $text_color,
        $hide_data,
        $table_id,
        $table_class,
        $row_buttons,
        $edit_remove,
        $key
    );
}

/**
 * Generate a beautiful, modern UI table with DataTables integration
 * Optimized for web interfaces with advanced styling and functionality
 *
 * @param array $data The data to display in the table
 * @param string|false $module Module name for linking
 * @param string|false $grand_total Field name for grand total calculation
 * @param string|false $date_for Start date filter
 * @param string|false $date_end End date filter
 * @param array $row_colors Row styling configuration
 * @param bool $hide_data Whether to hide the table initially
 * @param string|false $table_id Custom table ID
 * @param string|false $table_class Additional CSS classes
 * @param bool $row_buttons Whether to show row action buttons
 * @param bool $edit_remove Whether to show edit/remove buttons
 * @param string|false $key Custom key field
 * @return void Outputs HTML directly
 */
function outright_html_table_ui(
    array $data,
    $module = false,
    $grand_total = false,
    $date_for = false,
    $date_end = false,
    array $row_colors = ['even' => '#f8fafc', 'odd' => '#ffffff', 'text_color' => '#1f2937'],
    $hide_data = false,
    $table_id = false,
    $table_class = false,
    $row_buttons = false,
    $edit_remove = false,
    $key = false
) {
    // Configuration
    $config = [
        'sugar_url' => $GLOBALS['sugar_config']['site_url'] ?? '',
        'table_id' => $table_id ?: 'modernDataTable_' . uniqid(),
        'skip_columns' => ['id', 'envelopeId'],
        'linkable_fields' => ['id', 'first_name', 'name', 'document_name'],
        'theme_colors' => [
            'primary' => '#3b82f6',
            'secondary' => '#6366f1',
            'success' => '#10b981',
            'warning' => '#f59e0b',
            'danger' => '#ef4444',
            'info' => '#06b6d4',
            'dark' => '#1f2937',
            'light' => '#f8fafc'
        ]
    ];

    // Normalize data
    if (!isset($data[0]) || !is_array($data[0])) {
        $data = [$data];
    }

    if (empty($data) || empty($data[0])) {
        echo generateUIEmptyState($config);
        return;
    }

    // Output components
    echo loadExternalAssets();
    echo generateAdvancedStyles($config, $row_colors);
    echo generateTableHeader(count($data), $config);
    echo generateDataTable($data, $config, $row_colors, $module, $hide_data, $table_class);

    // Add grand total if requested
    if ($grand_total && $module) {
        echo generateGrandTotalCard($grand_total, $module, $date_for, $date_end, $config);
    }

    echo generateDataTablesScript($config['table_id']);
}

/**
 * Load external CSS and JS assets with modern versions
 */
function loadExternalAssets(): string
{
    return '
    <!-- Modern DataTables with responsive design -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Bootstrap 5 for modern styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- jQuery and DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
    ';
}

/**
 * Generate advanced CSS styles for the modern UI
 */
function generateAdvancedStyles(array $config, array $row_colors): string
{
    $colors = $config['theme_colors'];

    return "
    <style>
        :root {
            --primary-color: {$colors['primary']};
            --secondary-color: {$colors['secondary']};
            --success-color: {$colors['success']};
            --warning-color: {$colors['warning']};
            --danger-color: {$colors['danger']};
            --info-color: {$colors['info']};
            --dark-color: {$colors['dark']};
            --light-color: {$colors['light']};
        }
        
        .modern-table-container {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 30px;
            border-radius: 20px;
            margin: 20px 0;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        
        .table-header-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
        }
        
        .table-title {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .record-count {
            font-size: 18px;
            color: var(--dark-color);
            font-weight: 500;
        }
        
        .record-count .count-number {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
            padding: 8px 16px;
            border-radius: 25px;
            font-weight: 700;
            margin-left: 10px;
            display: inline-block;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.4);
        }
        
        .modern-datatable {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none !important;
        }
        
        .modern-datatable thead th {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
            color: white !important;
            font-weight: 600 !important;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 13px !important;
            padding: 18px 12px !important;
            border: none !important;
            text-align: center !important;
            position: relative;
        }
        
        .modern-datatable thead th:first-child {
            border-radius: 0;
        }
        
        .modern-datatable thead th:last-child {
            border-radius: 0;
        }
        
        .modern-datatable thead th::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        }
        
        .modern-datatable tbody tr {
            transition: all 0.3s ease;
            border: none !important;
        }
        
        .modern-datatable tbody tr:nth-child(even) {
            background-color: {$row_colors['even']} !important;
        }
        
        .modern-datatable tbody tr:nth-child(odd) {
            background-color: {$row_colors['odd']} !important;
        }
        
        .modern-datatable tbody tr:hover {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.05), rgba(99, 102, 241, 0.05)) !important;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .modern-datatable tbody td {
            padding: 16px 12px !important;
            vertical-align: middle !important;
            border: none !important;
            font-size: 14px;
            color: var(--dark-color);
            text-align: center !important;
        }
        
        .serial-badge {
            background: linear-gradient(135deg, var(--info-color), #0891b2);
            color: white;
            padding: 8px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 12px;
            display: inline-block;
            min-width: 35px;
            box-shadow: 0 4px 12px rgba(6, 182, 212, 0.3);
        }
        
        .record-link {
            color: var(--primary-color) !important;
            text-decoration: none !important;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 25px;
            background: rgba(59, 130, 246, 0.1);
            transition: all 0.3s ease;
            display: inline-block;
            border: 2px solid transparent;
        }
        
        .record-link:hover {
            background: var(--primary-color) !important;
            color: white !important;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(59, 130, 246, 0.4);
            border-color: var(--primary-color);
        }
        
        .external-link {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white !important;
            text-decoration: none !important;
            padding: 10px 20px;
            border-radius: 25px;
            font-weight: 600;
            font-size: 13px;
            transition: all 0.3s ease;
            display: inline-block;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }
        
        .external-link:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.5);
            color: white !important;
        }
        
        .grand-total-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 30px;
            margin-top: 25px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
        }
        
        .grand-total-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 15px;
        }
        
        .grand-total-value {
            font-size: 36px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--success-color), #059669);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
        }
        
        .grand-total-label {
            font-size: 16px;
            color: #6b7280;
            font-weight: 500;
        }
        
        /* DataTables custom styling */
        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_filter,
        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_paginate {
            color: white !important;
            font-weight: 500;
        }
        
        .dataTables_wrapper .dataTables_filter input {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 25px;
            padding: 8px 16px;
            color: white;
            margin-left: 10px;
        }
        
        .dataTables_wrapper .dataTables_filter input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        
        .dataTables_wrapper .dataTables_length select {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            padding: 5px 10px;
            color: white;
            margin: 0 10px;
        }
        
        .page-link {
            background: rgba(255, 255, 255, 0.2) !important;
            border: 1px solid rgba(255, 255, 255, 0.3) !important;
            color: white !important;
            border-radius: 8px !important;
            margin: 0 2px;
        }
        
        .page-link:hover {
            background: rgba(255, 255, 255, 0.3) !important;
            color: white !important;
        }
        
        .page-item.active .page-link {
            background: var(--primary-color) !important;
            border-color: var(--primary-color) !important;
        }
        
        .dt-buttons {
            margin-bottom: 20px;
        }
        
        .dt-button {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
            color: white !important;
            border: none !important;
            padding: 10px 20px !important;
            border-radius: 25px !important;
            font-weight: 600 !important;
            margin-right: 10px !important;
            transition: all 0.3s ease !important;
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3) !important;
        }
        
        .dt-button:hover {
            transform: translateY(-2px) !important;
            box-shadow: 0 8px 25px rgba(59, 130, 246, 0.5) !important;
        }
        
        .empty-state {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 60px 30px;
            text-align: center;
            margin: 20px 0;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
        }
        
        .empty-state-icon {
            font-size: 64px;
            color: #d1d5db;
            margin-bottom: 20px;
        }
        
        .empty-state-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 10px;
        }
        
        .empty-state-message {
            font-size: 16px;
            color: #6b7280;
        }
        
        @media (max-width: 768px) {
            .modern-table-container {
                padding: 15px;
                margin: 10px;
            }
            
            .table-title {
                font-size: 22px;
            }
            
            .modern-datatable thead th {
                font-size: 11px !important;
                padding: 12px 6px !important;
            }
            
            .modern-datatable tbody td {
                padding: 12px 6px !important;
                font-size: 12px;
            }
        }
    </style>";
}

/**
 * Generate UI empty state
 */
function generateUIEmptyState(array $config): string
{
    return '
    <div class="modern-table-container">
        <div class="empty-state">
            <div class="empty-state-icon">
                <i class="fas fa-table"></i>
            </div>
            <div class="empty-state-title">No Data Available</div>
            <div class="empty-state-message">There are no records to display at this time.</div>
        </div>
    </div>';
}

/**
 * Generate table header section
 */
function generateTableHeader(int $recordCount, array $config): string
{
    return '
    <div class="modern-table-container">
        <div class="table-header-card">
            <div class="table-title">
                <i class="fas fa-database"></i> Data Overview
            </div>
            <div class="record-count">
                Total Records<span class="count-number">' . number_format($recordCount) . '</span>
            </div>
        </div>';
}

/**
 * Generate the main data table
 */
function generateDataTable(array $data, array $config, array $row_colors, $module, $hide_data, $table_class): string
{
    $hideStyle = $hide_data ? 'style="display:none"' : '';
    $tableClass = "modern-datatable table table-striped table-hover {$table_class}";

    $html = '<table id="' . $config['table_id'] . '" class="' . $tableClass . '" ' . $hideStyle . '>';

    // Generate table header
    $html .= '<thead><tr><th><i class="fas fa-hashtag"></i> Sr.No</th>';

    foreach (array_keys($data[0]) as $field) {
        if (in_array($field, $config['skip_columns'])) {
            continue;
        }

        $displayName = formatUIFieldName($field);
        $icon = getFieldIcon($field);
        $html .= "<th>{$icon} {$displayName}</th>";
    }

    $html .= '</tr></thead><tbody>';

    // Generate table body
    foreach ($data as $index => $row) {
        $serialNumber = $index + 1;
        $html .= '<tr>';
        $html .= '<td><span class="serial-badge">' . $serialNumber . '</span></td>';

        foreach ($row as $field => $value) {
            if (in_array($field, $config['skip_columns'])) {
                continue;
            }

            $html .= '<td>' . formatUICellValue($field, $value, $row, $config, $module) . '</td>';
        }

        $html .= '</tr>';
    }

    $html .= '</tbody></table></div>';

    return $html;
}

/**
 * Format field names for UI display
 */
function formatUIFieldName(string $field): string
{
    $formatted = str_replace(['_', '-'], ' ', $field);
    return ucwords($formatted);
}

/**
 * Get appropriate icon for field
 */
function getFieldIcon(string $field): string
{
    $icons = [
        'name' => '<i class="fas fa-user"></i>',
        'email' => '<i class="fas fa-envelope"></i>',
        'phone' => '<i class="fas fa-phone"></i>',
        'date' => '<i class="fas fa-calendar"></i>',
        'amount' => '<i class="fas fa-dollar-sign"></i>',
        'status' => '<i class="fas fa-flag"></i>',
        'link' => '<i class="fas fa-link"></i>',
        'document' => '<i class="fas fa-file"></i>',
    ];

    foreach ($icons as $key => $icon) {
        if (stripos($field, $key) !== false) {
            return $icon;
        }
    }

    return '<i class="fas fa-info-circle"></i>';
}

/**
 * Format cell values for UI display
 */
function formatUICellValue(string $field, $value, array $row, array $config, $module): string
{
    // Handle linkable fields
    if (in_array($field, $config['linkable_fields']) && $module && isset($row['id'])) {
        $url = $config['sugar_url'] . "/index.php?action=DetailView&module={$module}&record={$row['id']}";
        return '<a href="' . $url . '" class="record-link" target="_blank">' . htmlspecialchars($value) . '</a>';
    }

    // Handle external links
    if ($field === 'link' && filter_var($value, FILTER_VALIDATE_URL)) {
        return '<a href="' . $value . '" class="external-link" target="_blank">
                    <i class="fas fa-external-link-alt"></i> Open Link
                </a>';
    }

    // Handle dates
    if (strtotime($value) && preg_match('/\d{4}-\d{2}-\d{2}/', $value)) {
        return '<span class="date-badge"><i class="fas fa-calendar"></i> ' . date('M j, Y', strtotime($value)) . '</span>';
    }

    // Handle numbers
    if (is_numeric($value) && $value != (int)$value) {
        return '<span class="number-badge">' . number_format((float)$value, 2) . '</span>';
    }

    // Handle status-like fields
    if (stripos($field, 'status') !== false) {
        $statusClass = strtolower($value) === 'active' ? 'success' : 'secondary';
        return '<span class="badge bg-' . $statusClass . '">' . htmlspecialchars($value) . '</span>';
    }

    return htmlspecialchars($value ?? '');
}

/**
 * Generate grand total card
 */
function generateGrandTotalCard(string $grandTotalField, string $module, $dateFor, $dateEnd, array $config): string
{
    $sql = buildGrandTotalQuery($grandTotalField, $module, $dateFor, $dateEnd);

    if (!$sql) {
        return '';
    }

    $result = outright_run_sql_one_row($sql);
    $fieldLabel = formatUIFieldName($grandTotalField);
    $total = number_format($result['Count'] ?? 0, 2);

    return '
        <div class="grand-total-card">
            <div class="grand-total-title">
                <i class="fas fa-calculator"></i> Grand Total Summary
            </div>
            <div class="grand-total-value">' . $total . '</div>
            <div class="grand-total-label">Total ' . $fieldLabel . '</div>
        </div>
    </div>';
}

/**
 * Build SQL query for grand total calculation
 */
function buildGrandTotalQuery(string $field, string $module, $dateFor, $dateEnd): string
{
    $baseQuery = "SELECT SUM({$field}) as Count FROM " . strtolower($module) . " WHERE deleted=0";

    if ($dateFor && $dateEnd) {
        return $baseQuery . " AND DATE(date_entered) BETWEEN '{$dateFor}' AND '{$dateEnd}'";
    } elseif ($dateFor) {
        return $baseQuery . " AND DATE(date_entered) = '{$dateFor}'";
    }

    return $baseQuery;
}

/**
 * Generate DataTables initialization script
 */
function generateDataTablesScript(string $tableId): string
{
    return "
    <script>
    $(document).ready(function() {
        $('#{$tableId}').DataTable({
            responsive: true,
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'All']],
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'copy',
                    text: '<i class=\"fas fa-copy\"></i> Copy',
                    className: 'btn-copy'
                },
                {
                    extend: 'csv',
                    text: '<i class=\"fas fa-file-csv\"></i> CSV',
                    className: 'btn-csv'
                },
                {
                    extend: 'excel',
                    text: '<i class=\"fas fa-file-excel\"></i> Excel',
                    className: 'btn-excel'
                },
                {
                    extend: 'pdf',
                    text: '<i class=\"fas fa-file-pdf\"></i> PDF',
                    className: 'btn-pdf',
                    orientation: 'landscape',
                    pageSize: 'A4'
                },
                {
                    extend: 'print',
                    text: '<i class=\"fas fa-print\"></i> Print',
                    className: 'btn-print'
                }
            ],
            language: {
                search: '<i class=\"fas fa-search\"></i>',
                searchPlaceholder: 'Search records...',
                lengthMenu: 'Show _MENU_ entries',
                info: 'Showing _START_ to _END_ of _TOTAL_ entries',
                infoEmpty: 'No entries available',
                infoFiltered: '(filtered from _MAX_ total entries)',
                paginate: {
                    first: '<i class=\"fas fa-angle-double-left\"></i>',
                    previous: '<i class=\"fas fa-angle-left\"></i>',
                    next: '<i class=\"fas fa-angle-right\"></i>',
                    last: '<i class=\"fas fa-angle-double-right\"></i>'
                }
            },
            columnDefs: [
                { 
                    targets: 0, 
                    orderable: false,
                    searchable: false,
                    className: 'text-center'
                }
            ],
            order: [[1, 'asc']],
            scrollX: true,
            fixedHeader: true,
            stateSave: true,
            drawCallback: function(settings) {
                // Add animation to new rows
                $('#{$tableId} tbody tr').addClass('animate__animated animate__fadeIn');
            }
        });
        
        // Add custom search functionality
        $('#{$tableId}_filter input').addClass('form-control');
        
        // Add loading animation
        $('#{$tableId}').on('processing.dt', function(e, settings, processing) {
            if (processing) {
                $(this).addClass('loading');
            } else {
                $(this).removeClass('loading');
            }
        });
    });
    </script>";
}

// function mailto_indexing_status() {
//     // ✅ SQL Query for latest 5 blogs
//     $sql = "SELECT b.id, b.name, b.date_entered, b.blog_url, c.indexing_c
//             FROM outr_published_blogs b
//             JOIN outr_published_blogs_cstm c ON b.id = c.id_c
//             WHERE b.deleted = 0
//               AND c.indexing_c = 1
//               AND b.name = 'outrightcrm.com'
//             ORDER BY b.date_entered DESC ";

//     $result = outright_run_sql($sql);

//     if (empty($result)) {
//         return true; // nothing found but still return true
//     }

//     // ✅ Prepare email body
//     $body = "Hello Team,\n\n";
//     $body .= "The following blogs have been marked as not indexed:\n\n";

//     foreach ($result as $i => $row) {
//         $body .= "🔹 Blog #" . ($i+1) . "\n";
//         $body .= "📌 Title: " . $row['name'] . "\n";
//         $body .= "📌 URL: " . $row['blog_url'] . "\n";
//         $body .= "📌 Date: " . $row['date_entered'] . "\n\n";
//     }

//     $body .= "Regards,\nCRM System";

//     // ✅ Mail Settings
//     $to = "outrightcrm32@gmail.com";
//     $subject = "✅ Latest Not Indexed Blogs - outrightcrm.com";

//     require_once("include/SugarPHPMailer.php");
//     $mail = new SugarPHPMailer();
//     $mail->setMailerForSystem();
//     $mail->From = "no-reply@outrightcrm.com";
//     $mail->FromName = "OutrightCRM System";
//     $mail->Subject = $subject;
//     $mail->Body = $body;
//     $mail->prepForOutbound();
//     $mail->AddAddress($to);

//     // ✅ Send email
//     $mail->Send();
//     return true; 
// }



// its working
// function mailto_indexing_status() {
//     // SQL Query for latest 5 blogs where indexing_c = 1 (Not Indexed)
//     $sql = "SELECT b.id, b.name, b.date_entered, b.blog_url, c.indexing_c
//             FROM outr_published_blogs b
//             JOIN outr_published_blogs_cstm c ON b.id = c.id_c
//             WHERE b.deleted = 0 
//               AND b.name = 'outrightcrm.com'
//               AND b.date_entered >= DATE_SUB(NOW(), INTERVAL 3 DAY) 
//             ORDER BY b.date_entered DESC
//             LIMIT 5";

//     $result = outright_run_sql($sql);

//     if (empty($result)) {
//         echo "❌ No blogs found in last 3 days.";
//         return true;
//     }

//     $notIndexed = [];
//     foreach ($result as $row) {
//         if (isset($row['indexing_c']) && $row['indexing_c'] == 1) {
//             $notIndexed[] = $row;
//         }
//     }

//     // Build email
//     // $to = "outrightcrm32@gmail.com, sales@outrightcrm.com";

//     require_once('include/SugarPHPMailer.php'); // adjust path if needed
//     $mail = new SugarPHPMailer();
//     $mail->setMailerForSystem();
//     $mail->From = "no-reply@outrightcrm.com";
//     $mail->FromName = "OutrightCRM System";

//     if (!empty($notIndexed)) {
//         // Case 1: Found not indexed blogs
//         $subject = "❌ Latest Not Indexed Blogs - outrightcrm.com";
//         $body = "Hello Team,\n\n";
//         $body .= "The following blogs have been marked as NOT indexed in the last 3 days:\n\n";

//         foreach ($notIndexed as $i => $row) {
//             $body .= "🔹 Blog #" . ($i+1) . "\n";
//             $body .= "📌 Title: " . $row['name'] . "\n";
//             $body .= "📌 URL: " . $row['blog_url'] . "\n";
//             $body .= "📌 Date: " . $row['date_entered'] . "\n\n";
//         }

//         $body .= "Regards,\nCRM System";
//     } else {
//         // Case 2: All indexed
//         $subject = "✅ All Blogs Indexed - outrightcrm.com";
//         $body = "Hello Team,\n\n";
//         $body .= "Good news! All blogs published in the last 3 days are indexed successfully. 🎉\n\n";
//         $body .= "Regards,\nCRM System";
//     }

//     $mail->Subject = $subject;
//     $mail->Body = $body;
//     $mail->prepForOutbound();
// 	    $recipients = ["outrightcrm32@gmail.com", "sales@outrightcrm.com"];
//     foreach ($recipients as $to) {
//         $mail->AddAddress($to);
//     }

//     // $mail->AddAddress($to);

//     if ($mail->Send()) {
//         echo "✅ Email sent successfully to " . $to;
//     } else {
//         echo "❌ Email sending failed. Error: " . $mail->ErrorInfo;
//     }

//     return true;
// }



// multiple name field
function mailto_indexing_status()
{
    // Define all site names
    $sites = [
        "outrightcrm.com",
        "OutRightSystems.org",
        "store.outrightcrm.com"
    ];

    require_once('include/SugarPHPMailer.php'); // adjust path if needed

    foreach ($sites as $siteName) {

        // SQL Query for latest 5 blogs in last 3 days for this site
        $sql = "SELECT b.id, b.name, b.date_entered, b.blog_url, c.indexing_c
                FROM outr_published_blogs b
                JOIN outr_published_blogs_cstm c ON b.id = c.id_c
                WHERE b.deleted = 0 
                  AND b.name = '{$siteName}'
                  AND b.date_entered >= DATE_SUB(NOW(), INTERVAL 3 DAY) 
                ORDER BY b.date_entered DESC
                LIMIT 5";

        $result = outright_run_sql($sql);

        if (empty($result)) {
            echo "❌ No blogs found in last 3 days for {$siteName}.<br>";
            continue; // go to next site
        }

        $notIndexed = [];
        foreach ($result as $row) {
            if (isset($row['indexing_c']) && $row['indexing_c'] == 1) {
                $notIndexed[] = $row;
            }
        }

        // Build mail
        $mail = new SugarPHPMailer();
        $mail->setMailerForSystem();
        $mail->From = "no-reply@outrightcrm.com";
        $mail->FromName = "OutrightCRM System";
        $mail->IsHTML(true); // use HTML body

        if (!empty($notIndexed)) {
            // Case 1: Found not indexed blogs
            $subject = "❌ Latest Not Indexed Blogs - {$siteName}";

            $body = '<html><body style="font-family: Arial, sans-serif; color:#333;">';
            $body .= '<h2 style="color:#d9534f;">❌ Not Indexed Blogs</h2>';
            $body .= '<p><b>Domain:</b> ' . $siteName . '</p>';
            $body .= '<p>The following blogs have been marked as <b>NOT indexed</b> in the last 3 days:</p>';

            $body .= '<table border="1" cellspacing="0" cellpadding="8" style="border-collapse:collapse; width:100%;">';
            $body .= '<thead style="background:#f2f2f2;">';
            $body .= '<tr>';
            $body .= '<th style="text-align:left;">Blog URL</th>';
            $body .= '<th style="text-align:left;">Status</th>';
            $body .= '<th style="text-align:left;">Publish Date</th>';
            $body .= '</tr>';
            $body .= '</thead><tbody>';

            foreach ($notIndexed as $row) {
                $body .= '<tr>';
                $body .= '<td><a href="' . $row['blog_url'] . '" target="_blank">' . $row['blog_url'] . '</a></td>';
                $body .= '<td style="color:#d9534f; font-weight:bold;">Not Indexed</td>';
                $body .= '<td>' . date("d M Y, H:i", strtotime($row['date_entered'])) . '</td>';
                $body .= '</tr>';
            }

            $body .= '</tbody></table>';
            $body .= '<p style="margin-top:20px;">Regards,<br><b>CRM System</b></p>';
            $body .= '</body></html>';
        } else {
            // Case 2: All indexed
            $subject = "✅ All Blogs Indexed - {$siteName}";

            $body = '<html><body style="font-family: Arial, sans-serif; color:#333;">';
            $body .= '<div style="border:1px solid #28a745; border-radius:8px; padding:20px; background:#eafaf1; max-width:600px;">';
            $body .= '<h2 style="color:#28a745; margin-top:0;">🎉 Congratulations!</h2>';
            $body .= '<p>All latest blogs for <b>' . $siteName . '</b> published in the last 3 days are successfully <b>Indexed</b>.</p>';
            $body .= '<p style="font-weight:bold; color:#155724;">Great work team! 🚀</p>';
            $body .= '</div>';
            $body .= '<p style="margin-top:20px;">Regards,<br><b>CRM System</b></p>';
            $body .= '</body></html>';
        }

        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->prepForOutbound();

        // Add recipients
        $recipients = ["outrightcrm32@gmail.com", "sales@outrightcrm.com"];
        foreach ($recipients as $to) {
            $mail->AddAddress($to);
        }

        if ($mail->Send()) {
            echo "✅ Email sent successfully for {$siteName}.<br>";
        } else {
            echo "❌ Email sending failed for {$siteName}. Error: " . $mail->ErrorInfo . "<br>";
        }
    }

    return true;
}

function outright_retrieve_list($module, $where = [], $order_by = '', $direction = 'DESC', $limit_from = 0, $limit_to = 100, $dateformat = false)
{
    global $db;

    $module_name = strtolower($module);

    // ✅ ORDER + LIMIT
    $order_by = !empty($order_by) ? $order_by : 'date_entered';
    $direction = strtoupper($direction) === 'ASC' ? 'ASC' : 'DESC';

    $limit = " LIMIT {$limit_from},{$limit_to}";

    // ✅ Helper: Build WHERE safely
    $buildWhere = function ($where, $main_cols = [], $custom_cols = [], $prefix_main = '', $prefix_custom = '') use ($db) {
        $cond = [];

        foreach ($where as $key => $value) {
            // detect table prefix
            if (in_array($key, $main_cols)) {
                $col = ($prefix_main ? $prefix_main . '.' : '') . $key;
            } elseif (in_array($key, $custom_cols)) {
                $col = ($prefix_custom ? $prefix_custom . '.' : '') . $key;
            } else {
                $col = ($prefix_main ? $prefix_main . '.' : '') . $key;
            }

            // ✅ Range
            if (is_array($value) && isset($value['>=']) && isset($value['<='])) {
                $cond[] = "$col >= '" . $db->quote($value['>=']) . "' AND $col <= '" . $db->quote($value['<=']) . "'";
            }

            // ✅ IN
            elseif (is_array($value)) {
                $vals = array_map([$db, 'quote'], $value);
                $cond[] = "$col IN ('" . implode("','", $vals) . "')";
            }

            // ✅ LIKE
            elseif (strpos($value, '%') !== false) {
                $cond[] = "$col LIKE '" . $db->quote($value) . "'";
            }

            // ✅ Normal =
            else {
                $cond[] = "$col = '" . $db->quote($value) . "'";
            }
        }

        return !empty($cond) ? ' AND ' . implode(' AND ', $cond) : '';
    };

    // =========================================================
    // 📧 EMAILS MODULE (SPECIAL CASE)
    // =========================================================
    if ($module_name === 'emails') {

        $cond = " WHERE e.deleted = 0";

        $email_cols = array_column(outright_run_sql("SHOW COLUMNS FROM emails"), 'Field');
        $text_cols = array_column(outright_run_sql("SHOW COLUMNS FROM emails_text"), 'Field');
        $rel_cols = array_column(outright_run_sql("SHOW COLUMNS FROM emails_email_addr_rel"), 'Field');
        $addr_cols = array_column(outright_run_sql("SHOW COLUMNS FROM email_addresses"), 'Field');

        $table_map = [
            'e' => $email_cols,
            'et' => $text_cols,
            'ear' => $rel_cols,
            'ea' => $addr_cols
        ];

        if (!empty($where)) {
            foreach ($where as $key => $value) {
                $prefix = 'e';
                foreach ($table_map as $p => $cols) {
                    if (in_array($key, $cols)) {
                        $prefix = $p;
                        break;
                    }
                }

                if (is_array($value) && isset($value['>=']) && isset($value['<='])) {
                    $cond .= " AND {$prefix}.{$key} >= '" . $db->quote($value['>=']) . "' 
                               AND {$prefix}.{$key} <= '" . $db->quote($value['<=']) . "'";
                } elseif (is_array($value)) {
                    $vals = array_map([$db, 'quote'], $value);
                    $cond .= " AND {$prefix}.{$key} IN ('" . implode("','", $vals) . "')";
                } elseif (strpos($value, '%') !== false) {
                    $cond .= " AND {$prefix}.{$key} LIKE '" . $db->quote($value) . "'";
                } else {
                    $cond .= " AND {$prefix}.{$key} = '" . $db->quote($value) . "'";
                }
            }
        }

        $sql = "SELECT e.*, et.from_addr, et.to_addrs, et.cc_addrs, et.bcc_addrs,
                       et.description, et.description_html,
                       ea.email_address
                FROM emails e
                LEFT JOIN emails_text et ON e.id = et.email_id
                LEFT JOIN emails_email_addr_rel ear ON e.id = ear.email_id AND ear.deleted = 0
                LEFT JOIN email_addresses ea ON ear.email_address_id = ea.id AND ea.deleted = 0
                {$cond}
                ORDER BY e.{$order_by} {$direction}
                {$limit}";

        return outright_run_sql($sql);
    }

    // =========================================================
    // 📦 NORMAL MODULES
    // =========================================================

    $has_custom = outright_run_sql_one_row("SHOW TABLES LIKE '{$module_name}_cstm'");

    $main_cols = array_column(outright_run_sql("SHOW COLUMNS FROM {$module_name}"), 'Field');
    $custom_cols = $has_custom ? array_column(outright_run_sql("SHOW COLUMNS FROM {$module_name}_cstm"), 'Field') : [];

    // base condition
    $cond = $has_custom ? " WHERE m.deleted = 0" : " WHERE deleted = 0";

    // deleted override
    if (isset($where['deleted'])) {
        $cond = $has_custom ? " WHERE m.deleted = " . intval($where['deleted']) : " WHERE deleted = " . intval($where['deleted']);
        unset($where['deleted']);
    }

    // build WHERE
    if (!empty($where)) {
        $cond .= $buildWhere(
            $where,
            $main_cols,
            $custom_cols,
            $has_custom ? 'm' : '',
            $has_custom ? 'ct' : ''
        );
    }

    // build SQL
    if ($has_custom) {
        $sql = "SELECT * FROM {$module_name} m
                INNER JOIN {$module_name}_cstm ct ON m.id = ct.id_c
                {$cond}
                ORDER BY m.{$order_by} {$direction}
                {$limit}";
    } else {
        $sql = "SELECT * FROM {$module_name}
                {$cond}
                ORDER BY {$order_by} {$direction}
                {$limit}";
    }

    $data = outright_run_sql($sql);

    // ✅ Date formatting
    if ($dateformat && !empty($data)) {
        foreach ($data as &$row) {
            if (!empty($row['date_entered'])) {
                $row['real_date_entered'] = $row['date_entered'] ;
                $row['date_entered'] = timeAgoDetailed($row['date_entered']);
                $row['date_entered_formatted'] = addFiveThirtyHours($row['date_entered']);
            }
            if (!empty($row['date_modified'])) {
                $row['real_date_modified'] = $row['date_modified'] ;
                $row['date_modified'] = timeAgoDetailed($row['date_modified']);
                $row['date_modified_formatted'] = addFiveThirtyHours($row['date_modified']);
            }
        }
    }

    return $data;
}
function timeAgoDetailed($date_entered)
{
    $start = new DateTime($date_entered);
    $now   = new DateTime();

    $diff = $start->diff($now);

    // Years + Months
    if ($diff->y > 0) {
        return "{$diff->y} year" . ($diff->y > 1 ? "s " : " ") . "{$diff->m} month" . ($diff->m > 1 ? "s " : " ") . "ago";
    }

    // Months + Days
    if ($diff->m > 0) {
        return "{$diff->m} month" . ($diff->m > 1 ? "s " : " ") . "{$diff->d} day" . ($diff->d > 1 ? "s " : " ") . "ago";
    }

    // Days + Hours
    if ($diff->d > 0) {
        return "{$diff->d} day" . ($diff->d > 1 ? "s " : " ") . "{$diff->h} hour" . ($diff->h > 1 ? "s " : " ") . "ago";
    }

    // Hours + Minutes
    if ($diff->h > 0) {
        return "{$diff->h} hour" . ($diff->h > 1 ? "s " : " ") . "{$diff->i} min" . ($diff->i > 1 ? "s " : " ") . "ago";
    }

    // Only Minutes
    return "{$diff->i} min" . ($diff->i > 1 ? "s " : " ") . "ago";
}
