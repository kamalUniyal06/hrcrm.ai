<?php
/**
 * ajax.php
 *
 * Single AJAX entry point for Package Builder. Dispatches on $_REQUEST['pkgb_action'].
 * All actions require an authenticated admin user.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

global $current_user, $sugar_config;

if (empty($current_user) || !$current_user->isAdmin()) {
    PkgBuilder_Utils::jsonResponse(array('message' => 'Admin access required.'), false);
}

require_once 'custom/pkgbuilder/lib/Utils.php';
require_once 'custom/pkgbuilder/lib/ModuleScanner.php';
require_once 'custom/pkgbuilder/lib/RelationshipScanner.php';
require_once 'custom/pkgbuilder/lib/EntryPointScanner.php';
require_once 'custom/pkgbuilder/lib/ManifestBuilder.php';
require_once 'custom/pkgbuilder/lib/PackageAssembler.php';
require_once 'custom/pkgbuilder/lib/ZipBuilder.php';
require_once 'custom/pkgbuilder/lib/FieldTypes.php';
require_once 'custom/pkgbuilder/lib/VardefGenerator.php';
require_once 'custom/pkgbuilder/lib/LanguageGenerator.php';
require_once 'custom/pkgbuilder/lib/RepairTrigger.php';

$basePath = getcwd();
$action = isset($_REQUEST['pkgb_action']) ? $_REQUEST['pkgb_action'] : '';

switch ($action) {

    case 'scan_modules':
        $customOnly = !empty($_REQUEST['custom_only']) && $_REQUEST['custom_only'] !== 'false';
        $modules = PkgBuilder_ModuleScanner::scan($basePath, $customOnly);
        PkgBuilder_Utils::jsonResponse(array('modules' => $modules));
        break;

    case 'scan_relationships':
        $modules = readJsonArray('modules');      
        $modules = array_filter($modules, array('PkgBuilder_Utils', 'isValidIdentifier'));
        $relationships = PkgBuilder_RelationshipScanner::scan($basePath, $modules);
        PkgBuilder_Utils::jsonResponse(array('relationships' => $relationships));
        break;

    case 'scan_entrypoints':
        $entryPoints = PkgBuilder_EntryPointScanner::scan($basePath);
        PkgBuilder_Utils::jsonResponse(array('entry_points' => $entryPoints));
        break;

    case 'field_types':
        PkgBuilder_Utils::jsonResponse(array('types' => PkgBuilder_FieldTypes::$types));
        break;

    case 'generate_package':
        handleGeneratePackage($basePath);
        break;

    case 'download_package':
        handleDownloadPackage();
        break;

    case 'create_field':
        handleCreateField($basePath);
        break;

    default:
        PkgBuilder_Utils::jsonResponse(array('message' => 'Unknown action.'), false);
}

/**
 * Reads a request parameter that may arrive either as a real array
 * (e.g. modules[]=Jobs&modules[]=Contacts) or as a JSON-encoded string
 * (used by the fetch()-based UI below), and normalizes it to a PHP array.
 */
function readJsonArray($key)
{
    if (!isset($_REQUEST[$key])) {
        return array();
    }

    $raw = $_REQUEST[$key];

    // Already an array
    if (is_array($raw)) {
        return array_map('trim', $raw);
    }

    // Decode HTML entities (&quot; etc.)
    $raw = html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8');

    // Decode JSON
    $decoded = json_decode($raw, true);

    if (!is_array($decoded)) {
        return array();
    }

    // Remove spaces from values
    return array_map('trim', $decoded);
}

function handleGeneratePackage($basePath)
{
    $modules = array_values(array_filter(readJsonArray('modules'), array('PkgBuilder_Utils', 'isValidIdentifier')));
    if (empty($modules)) {
        PkgBuilder_Utils::jsonResponse(array('message' => 'Select at least one module.'), false);
    }

    $relationshipFiles = readJsonArray('relationships'); // array of relative file paths chosen in step 2
    $entryPointNames = readJsonArray('entry_points');    // array of entry point names chosen in step 3

    $allRelationships = PkgBuilder_RelationshipScanner::scan($basePath, $modules);
    $selectedRelationships = array_values(array_filter($allRelationships, function ($rel) use ($relationshipFiles) {
        return in_array($rel['file'], $relationshipFiles, true);
    }));

    $allEntryPoints = PkgBuilder_EntryPointScanner::scan($basePath);
    $selectedEntryPoints = array_values(array_filter($allEntryPoints, function ($ep) use ($entryPointNames) {
        return in_array($ep['name'], $entryPointNames, true);
    }));

    $packageInfo = array(
        'name'        => PkgBuilder_Utils::sanitizeText($_REQUEST['pkg_name'] ?? ''),
        'version'     => PkgBuilder_Utils::sanitizeVersion($_REQUEST['pkg_version'] ?? '1.0.0'),
        'author'      => PkgBuilder_Utils::sanitizeText($_REQUEST['pkg_author'] ?? ''),
        'description' => PkgBuilder_Utils::sanitizeText($_REQUEST['pkg_description'] ?? ''),
        'key'         => PkgBuilder_Utils::sanitizePackageName($_REQUEST['pkg_key'] ?? ($_REQUEST['pkg_name'] ?? 'CustomPackage')),
    );

    if ($packageInfo['name'] === '') {
        PkgBuilder_Utils::jsonResponse(array('message' => 'Package name is required.'), false);
    }
    if ($packageInfo['key'] === '') {
        PkgBuilder_Utils::jsonResponse(array('message' => 'Package key could not be derived - please set one.'), false);
    }

    $sanitizedFolderName = PkgBuilder_Utils::sanitizePackageName($packageInfo['name']);
    if ($sanitizedFolderName === '') {
        $sanitizedFolderName = $packageInfo['key'];
    }

    $workRoot = $basePath . '/custom/pkgbuilder/tmp';
    $buildId = uniqid('build_', true);
    $buildDir = $workRoot . '/' . $buildId . '/' . $sanitizedFolderName;

    if (!is_dir($buildDir) && !mkdir($buildDir, 0755, true)) {
        PkgBuilder_Utils::jsonResponse(array('message' => 'Could not create build directory.'), false);
    }

    try {
        $summary = PkgBuilder_PackageAssembler::assemble(
            $basePath,
            $buildDir,
            $modules,
            $selectedRelationships,
            $selectedEntryPoints
        );

        $manifestSrc = PkgBuilder_ManifestBuilder::build($packageInfo, $modules, $selectedRelationships);
        file_put_contents($buildDir . '/manifest.php', $manifestSrc);

        $readme = buildReadme($packageInfo, $modules, $selectedRelationships, $selectedEntryPoints);

        $outputDir = $workRoot . '/' . $buildId . '/output';
        $zipPath = PkgBuilder_ZipBuilder::build($buildDir, $sanitizedFolderName, $readme, $outputDir);

        // Store just the build id in session; the download action re-derives
        // the path server-side so we never trust a client-supplied path.
        session_start_if_needed();
        $_SESSION['pkgbuilder_last_build'] = $buildId . '/output/' . $sanitizedFolderName . '.zip';

        PkgBuilder_Utils::jsonResponse(array(
            'summary'      => $summary,
            'zip_name'     => $sanitizedFolderName . '.zip',
            'download_url' => 'index.php?entryPoint=PackageBuilderAjax&pkgb_action=download_package',
        ));
    } catch (Exception $e) {
        PkgBuilder_Utils::jsonResponse(array('message' => 'Package generation failed: ' . $e->getMessage()), false);
    }
}

function handleDownloadPackage()
{
    session_start_if_needed();
    if (empty($_SESSION['pkgbuilder_last_build'])) {
        header('HTTP/1.1 404 Not Found');
        echo 'No package available for download.';
        exit;
    }

    $relative = $_SESSION['pkgbuilder_last_build'];
    // Defense in depth: the value only ever comes from server-generated
    // uniqid() output, but validate its shape before touching the filesystem.
    if (!preg_match('#^build_[A-Za-z0-9.]+/output/[A-Za-z0-9_\-]+\.zip$#', $relative)) {
        header('HTTP/1.1 400 Bad Request');
        echo 'Invalid package reference.';
        exit;
    }

    $path = getcwd() . '/custom/pkgbuilder/tmp/' . $relative;
    if (!is_file($path)) {
        header('HTTP/1.1 404 Not Found');
        echo 'Package file not found - it may have expired.';
        exit;
    }

    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . basename($path) . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
}

function handleCreateField($basePath)
{
    $module = trim($_REQUEST['module'] ?? '');
    $fieldName = strtolower(trim($_REQUEST['field_name'] ?? ''));
    $label = trim($_REQUEST['label'] ?? '');
    $type = trim($_REQUEST['type'] ?? '');

    $field = array(
        'name'            => $fieldName,
        'type'            => $type,
        'len'             => $_REQUEST['length'] ?? '',
        'default'         => $_REQUEST['default_value'] ?? '',
        'required'        => !empty($_REQUEST['required']),
        'mass_update'     => !empty($_REQUEST['mass_update']),
        'reportable'      => !empty($_REQUEST['reportable']),
        'audited'         => !empty($_REQUEST['audited']),
        'importable'      => !empty($_REQUEST['importable']),
        'duplicate_merge' => !empty($_REQUEST['duplicate_merge']),
        'comment'         => $_REQUEST['comment'] ?? '',
        'help'            => $_REQUEST['help_text'] ?? '',
        'relate_module'   => $_REQUEST['relate_module'] ?? '',
        'dropdown_name'   => $_REQUEST['dropdown_name'] ?? '',
    );

    try {
        $vardefResult = PkgBuilder_VardefGenerator::append($basePath, $module, $field);
        if ($vardefResult['skipped_duplicate']) {
            PkgBuilder_Utils::jsonResponse(array(
                'message' => "Field '{$fieldName}' already exists in {$module} - not modified.",
            ), false);
        }

        $langResult = PkgBuilder_LanguageGenerator::append($basePath, $module, $fieldName, $label);

        $repairResult = PkgBuilder_RepairTrigger::run();

        PkgBuilder_Utils::jsonResponse(array(
            'vardef_file'   => $vardefResult['path'],
            'language_file' => $langResult['path'],
            'label_key'     => $langResult['label_key'],
            'repair'        => $repairResult,
        ));
    } catch (InvalidArgumentException $e) {
        PkgBuilder_Utils::jsonResponse(array('message' => $e->getMessage()), false);
    } catch (Exception $e) {
        PkgBuilder_Utils::jsonResponse(array('message' => 'Field creation failed: ' . $e->getMessage()), false);
    }
}

function session_start_if_needed()
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}

function buildReadme(array $packageInfo, array $modules, array $relationships, array $entryPoints)
{
    $lines = array();
    $lines[] = '# ' . $packageInfo['name'];
    $lines[] = '';
    $lines[] = $packageInfo['description'];
    $lines[] = '';
    $lines[] = '- Version: ' . $packageInfo['version'];
    $lines[] = '- Author: ' . $packageInfo['author'];
    $lines[] = '- Generated: ' . date('Y-m-d H:i:s');
    $lines[] = '';
    $lines[] = '## Modules';
    foreach ($modules as $m) {
        $lines[] = '- ' . $m;
    }
    $lines[] = '';
    $lines[] = '## Relationships';
    if (empty($relationships)) {
        $lines[] = '_None selected._';
    } else {
        foreach ($relationships as $r) {
            $lines[] = '- ' . $r['rel_name'] . ' (' . $r['file'] . ')';
        }
    }
    $lines[] = '';
    $lines[] = '## Entry Points';
    if (empty($entryPoints)) {
        $lines[] = '_None selected._';
    } else {
        foreach ($entryPoints as $e) {
            $lines[] = '- ' . $e['name'] . ' -> ' . $e['target_file'];
        }
    }
    $lines[] = '';
    $lines[] = '## Install';
    $lines[] = 'Admin > Module Loader > Upload the zip file, then click Install.';

    return implode("\n", $lines);
}
