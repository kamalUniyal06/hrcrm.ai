<?php
/**
 * export.php
 *
 * Admin-only entry point rendering the Package Builder wizard:
 *   Step 1: select modules (searchable multi-select, custom modules by default)
 *   Step 2: select relationships auto-scanned for the chosen modules
 *   Step 3: select entry points
 *   Step 4: package info -> generate -> download
 *
 * All data operations happen via custom/pkgbuilder/ui/ajax.php.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

global $current_user;

if (empty($current_user) || !$current_user->isAdmin()) {
    sugar_die('Unauthorized');
}

require_once 'include/MVC/View/SugarView.php';

$assetBase = 'custom/pkgbuilder/assets';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Package Builder - Export Module Package</title>
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/pkgbuilder.css">
</head>
<body>
<div class="pkgb-wrap">
    <h1>Package Builder &mdash; Export Module Package</h1>
    <p class="pkgb-sub">Bundle custom modules, their relationships, and entry points into an installable Module Loader ZIP.</p>

    <div class="pkgb-steps">
        <span class="pkgb-step active" data-step="1">1. Modules</span>
        <span class="pkgb-step" data-step="2">2. Relationships</span>
        <span class="pkgb-step" data-step="3">3. Entry Points</span>
        <span class="pkgb-step" data-step="4">4. Package Info</span>
        <span class="pkgb-step" data-step="5">5. Generate</span>
    </div>

    <!-- Step 1 -->
    <section class="pkgb-panel" id="panel-1">
        <label class="pkgb-checkbox-inline">
            <input type="checkbox" id="customOnlyToggle" checked>
            Show custom modules only
        </label>
        <input type="text" id="moduleSearch" placeholder="Search modules..." class="pkgb-input">
        <div id="moduleList" class="pkgb-list"></div>
        <div class="pkgb-actions">
            <button class="pkgb-btn pkgb-btn-primary" id="toStep2">Next: Relationships</button>
        </div>
    </section>

    <!-- Step 2 -->
    <section class="pkgb-panel" id="panel-2" style="display:none;">
        <p>Relationships found involving your selected modules:</p>
        <div id="relationshipList" class="pkgb-list"></div>
        <div class="pkgb-actions">
            <button class="pkgb-btn" id="backTo1">Back</button>
            <button class="pkgb-btn pkgb-btn-primary" id="toStep3">Next: Entry Points</button>
        </div>
    </section>

    <!-- Step 3 -->
    <section class="pkgb-panel" id="panel-3" style="display:none;">
        <p>Custom entry points registered on this instance:</p>
        <div id="entryPointList" class="pkgb-list"></div>
        <div class="pkgb-actions">
            <button class="pkgb-btn" id="backTo2">Back</button>
            <button class="pkgb-btn pkgb-btn-primary" id="toStep4">Next: Package Info</button>
        </div>
    </section>

    <!-- Step 4 -->
    <section class="pkgb-panel" id="panel-4" style="display:none;">
        <div class="pkgb-field">
            <label>Package Name</label>
            <input type="text" id="pkgName" class="pkgb-input" placeholder="e.g. Recruitment Modules">
        </div>
        <div class="pkgb-field">
            <label>Version</label>
            <input type="text" id="pkgVersion" class="pkgb-input" value="1.0.0">
        </div>
        <div class="pkgb-field">
            <label>Author</label>
            <input type="text" id="pkgAuthor" class="pkgb-input" placeholder="e.g. Outright Systems">
        </div>
        <div class="pkgb-field">
            <label>Description</label>
            <textarea id="pkgDescription" class="pkgb-input" rows="3"></textarea>
        </div>
        <div class="pkgb-field">
            <label>Key (unique package id, auto-filled from name)</label>
            <input type="text" id="pkgKey" class="pkgb-input">
        </div>
        <div class="pkgb-actions">
            <button class="pkgb-btn" id="backTo3">Back</button>
            <button class="pkgb-btn pkgb-btn-primary" id="toStep5">Next: Generate</button>
        </div>
    </section>

    <!-- Step 5 -->
    <section class="pkgb-panel" id="panel-5" style="display:none;">
        <div id="genSummary"></div>
        <div class="pkgb-actions">
            <button class="pkgb-btn" id="backTo4">Back</button>
            <button class="pkgb-btn pkgb-btn-primary" id="generateBtn">Generate Package</button>
        </div>
        <div id="genProgress" class="pkgb-progress" style="display:none;">
            <div class="pkgb-spinner"></div>
            <span>Building package&hellip;</span>
        </div>
        <div id="genResult" class="pkgb-result" style="display:none;"></div>
    </section>

    <div id="pkgbError" class="pkgb-error" style="display:none;"></div>
</div>

<script src="<?php echo $assetBase; ?>/pkgbuilder.js"></script>
</body>
</html>
