<?php
/**
 * field.php
 *
 * Admin-only entry point rendering the Custom Field Generator: builds a
 * vardef-based custom field for a chosen module and appends it (never
 * overwrites) to the module's Ext/Vardefs and Ext/Language extension files,
 * then triggers Quick Repair and Rebuild.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

global $current_user;

if (empty($current_user) || !$current_user->isAdmin()) {
    sugar_die('Unauthorized');
}

require_once 'custom/pkgbuilder/lib/FieldTypes.php';

$assetBase = 'custom/pkgbuilder/assets';
$fieldTypes = PkgBuilder_FieldTypes::$types;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Package Builder - Create Custom Field</title>
    <link rel="stylesheet" href="<?php echo $assetBase; ?>/pkgbuilder.css">
</head>
<body>
<div class="pkgb-wrap">
    <h1>Package Builder &mdash; Create Custom Field</h1>
    <p class="pkgb-sub">Adds a vardef-based custom field without Studio. Existing definitions are never overwritten.</p>

    <div class="pkgb-field">
        <label>Module</label>
        <select id="fModule" class="pkgb-input"></select>
    </div>

    <div class="pkgb-field">
        <label>Field Name</label>
        <input type="text" id="fName" class="pkgb-input" placeholder="my_field">
    </div>

    <div class="pkgb-field">
        <label>Label</label>
        <input type="text" id="fLabel" class="pkgb-input" placeholder="My Field">
    </div>

    <div class="pkgb-field">
        <label>Type</label>
        <select id="fType" class="pkgb-input">
            <?php foreach ($fieldTypes as $type => $info): ?>
                <option value="<?php echo htmlspecialchars($type); ?>"><?php echo htmlspecialchars($info['label']); ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="pkgb-field" id="lengthField">
        <label>Length</label>
        <input type="text" id="fLength" class="pkgb-input" placeholder="255">
    </div>

    <div class="pkgb-field" id="defaultField">
        <label>Default</label>
        <input type="text" id="fDefault" class="pkgb-input">
    </div>

    <div class="pkgb-field" id="relateModuleField" style="display:none;">
        <label>Related Module</label>
        <input type="text" id="fRelateModule" class="pkgb-input" placeholder="e.g. Contacts">
    </div>

    <div class="pkgb-field" id="dropdownField" style="display:none;">
        <label>Dropdown List Name (dom)</label>
        <input type="text" id="fDropdownName" class="pkgb-input" placeholder="e.g. my_field_list">
    </div>

    <div class="pkgb-checkbox-grid">
        <label><input type="checkbox" id="fRequired"> Required</label>
        <label><input type="checkbox" id="fMassUpdate" checked> Mass Update</label>
        <label><input type="checkbox" id="fReportable" checked> Reportable</label>
        <label><input type="checkbox" id="fAudited"> Audited</label>
        <label><input type="checkbox" id="fImportable" checked> Importable</label>
        <label><input type="checkbox" id="fDuplicateMerge"> Duplicate Merge</label>
    </div>

    <div class="pkgb-field">
        <label>Comment</label>
        <textarea id="fComment" class="pkgb-input" rows="2"></textarea>
    </div>

    <div class="pkgb-field">
        <label>Help Text</label>
        <textarea id="fHelp" class="pkgb-input" rows="2"></textarea>
    </div>

    <div class="pkgb-actions">
        <button class="pkgb-btn pkgb-btn-primary" id="saveFieldBtn">Save</button>
    </div>

    <div id="fieldProgress" class="pkgb-progress" style="display:none;">
        <div class="pkgb-spinner"></div>
        <span>Creating field&hellip;</span>
    </div>
    <div id="fieldResult" class="pkgb-result" style="display:none;"></div>
    <div id="pkgbError" class="pkgb-error" style="display:none;"></div>
</div>

<script>
    window.PKGB_FIELD_TYPES = <?php echo json_encode($fieldTypes); ?>;
</script>
<script src="<?php echo $assetBase; ?>/pkgbuilder.js"></script>
</body>
</html>
