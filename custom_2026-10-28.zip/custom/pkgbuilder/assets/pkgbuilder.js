(function () {
    'use strict';

    var AJAX_URL = 'index.php?entryPoint=PackageBuilderAjax';

    function post(action, params) {
        var body = new URLSearchParams(params || {});
        body.set('pkgb_action', action);
        return fetch(AJAX_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
            credentials: 'same-origin',
        }).then(function (r) { return r.json(); });
    }

    function showError(msg) {
        var el = document.getElementById('pkgbError');
        if (!el) { return; }
        el.textContent = msg;
        el.style.display = 'block';
    }

    function clearError() {
        var el = document.getElementById('pkgbError');
        if (el) { el.style.display = 'none'; }
    }

    // ---------------------------------------------------------------
    // Package Builder wizard (export.php)
    // ---------------------------------------------------------------
    function initWizard() {
        var state = {
            modules: [],           // selected module names
            allModules: [],
            relationships: [],     // selected relationship file paths
            allRelationships: [],
            entryPoints: [],       // selected entry point names
            allEntryPoints: [],
        };

        function showStep(n) {
            for (var i = 1; i <= 5; i++) {
                document.getElementById('panel-' + i).style.display = (i === n) ? '' : 'none';
            }
            var steps = document.querySelectorAll('.pkgb-step');
            steps.forEach(function (s) {
                s.classList.toggle('active', parseInt(s.getAttribute('data-step'), 10) === n);
            });
        }

        function renderModuleList(modules, filter) {
            var container = document.getElementById('moduleList');
            container.innerHTML = '';
            var filtered = modules.filter(function (m) {
                return !filter || m.name.toLowerCase().indexOf(filter.toLowerCase()) !== -1;
            });
            if (filtered.length === 0) {
                container.innerHTML = '<div class="pkgb-empty">No modules found.</div>';
                return;
            }
            filtered.forEach(function (m) {
                var row = document.createElement('label');
                row.className = 'pkgb-list-item';
                var checked = state.modules.indexOf(m.name) !== -1;
                row.innerHTML = '<input type="checkbox" data-module="' + m.name + '"' + (checked ? ' checked' : '') + '> ' + m.name +
                    (m.is_custom ? '<small>custom</small>' : '<small>stock</small>');
                container.appendChild(row);
            });
            container.querySelectorAll('input[type=checkbox]').forEach(function (cb) {
                cb.addEventListener('change', function () {
                    var name = cb.getAttribute('data-module');
                    if (cb.checked) {
                        if (state.modules.indexOf(name) === -1) { state.modules.push(name); }
                    } else {
                        state.modules = state.modules.filter(function (n) { return n !== name; });
                    }
                });
            });
        }

        function loadModules() {
            var customOnly = document.getElementById('customOnlyToggle').checked;
            post('scan_modules', { custom_only: customOnly ? 'true' : 'false' }).then(function (res) {
                if (!res.success) { showError(res.data.message); return; }
                state.allModules = res.data.modules;
                renderModuleList(state.allModules, document.getElementById('moduleSearch').value);
            });
        }

        function renderRelationshipList() {
            var container = document.getElementById('relationshipList');
            container.innerHTML = '';
            if (state.allRelationships.length === 0) {
                container.innerHTML = '<div class="pkgb-empty">No relationships found for the selected modules.</div>';
                return;
            }
            state.allRelationships.forEach(function (rel) {
                var row = document.createElement('label');
                row.className = 'pkgb-list-item';
                var checked = state.relationships.indexOf(rel.file) !== -1;
                row.innerHTML = '<input type="checkbox" data-file="' + rel.file + '"' + (checked ? ' checked' : '') + '> ' +
                    rel.rel_name + '<small>' + (rel.lhs_module || '?') + ' &harr; ' + (rel.rhs_module || '?') + '</small>';
                container.appendChild(row);
            });
            container.querySelectorAll('input[type=checkbox]').forEach(function (cb) {
                cb.addEventListener('change', function () {
                    var file = cb.getAttribute('data-file');
                    if (cb.checked) {
                        if (state.relationships.indexOf(file) === -1) { state.relationships.push(file); }
                    } else {
                        state.relationships = state.relationships.filter(function (f) { return f !== file; });
                    }
                });
            });
        }

        function loadRelationships() {
            post('scan_relationships', { modules: JSON.stringify(state.modules) }).then(function (res) {
                if (!res.success) { showError(res.data.message); return; }
                state.allRelationships = res.data.relationships;
                // Default: all pre-selected.
                state.relationships = state.allRelationships.map(function (r) { return r.file; });
                renderRelationshipList();
            });
        }

        function renderEntryPointList() {
            var container = document.getElementById('entryPointList');
            container.innerHTML = '';
            if (state.allEntryPoints.length === 0) {
                container.innerHTML = '<div class="pkgb-empty">No custom entry points registered.</div>';
                return;
            }
            state.allEntryPoints.forEach(function (ep) {
                var row = document.createElement('label');
                row.className = 'pkgb-list-item';
                var checked = state.entryPoints.indexOf(ep.name) !== -1;
                row.innerHTML = '<input type="checkbox" data-name="' + ep.name + '"' + (checked ? ' checked' : '') + '> ' +
                    ep.name + '<small>' + (ep.target_file || 'no file') + '</small>';
                container.appendChild(row);
            });
            container.querySelectorAll('input[type=checkbox]').forEach(function (cb) {
                cb.addEventListener('change', function () {
                    var name = cb.getAttribute('data-name');
                    if (cb.checked) {
                        if (state.entryPoints.indexOf(name) === -1) { state.entryPoints.push(name); }
                    } else {
                        state.entryPoints = state.entryPoints.filter(function (n) { return n !== name; });
                    }
                });
            });
        }

        function loadEntryPoints() {
            post('scan_entrypoints', {}).then(function (res) {
                if (!res.success) { showError(res.data.message); return; }
                state.allEntryPoints = res.data.entry_points;
                renderEntryPointList();
            });
        }

        document.getElementById('customOnlyToggle').addEventListener('change', loadModules);
        document.getElementById('moduleSearch').addEventListener('input', function () {
            renderModuleList(state.allModules, this.value);
        });

        document.getElementById('toStep2').addEventListener('click', function () {
            clearError();
            if (state.modules.length === 0) { showError('Select at least one module.'); return; }
            loadRelationships();
            showStep(2);
        });
        document.getElementById('backTo1').addEventListener('click', function () { showStep(1); });

        document.getElementById('toStep3').addEventListener('click', function () {
            loadEntryPoints();
            showStep(3);
        });
        document.getElementById('backTo2').addEventListener('click', function () { showStep(2); });

        document.getElementById('toStep4').addEventListener('click', function () { showStep(4); });
        document.getElementById('backTo3').addEventListener('click', function () { showStep(3); });

        document.getElementById('pkgName').addEventListener('input', function () {
            var keyField = document.getElementById('pkgKey');
            if (!keyField.dataset.manuallyEdited) {
                keyField.value = this.value.replace(/[^A-Za-z0-9_\-]/g, '');
            }
        });
        document.getElementById('pkgKey').addEventListener('input', function () {
            this.dataset.manuallyEdited = 'true';
        });

        document.getElementById('toStep5').addEventListener('click', function () {
            clearError();
            if (!document.getElementById('pkgName').value.trim()) { showError('Package name is required.'); return; }
            var summary = document.getElementById('genSummary');
            summary.innerHTML = '<p><strong>Modules:</strong> ' + state.modules.join(', ') + '</p>' +
                '<p><strong>Relationships:</strong> ' + (state.relationships.length || 'none') + '</p>' +
                '<p><strong>Entry points:</strong> ' + (state.entryPoints.length || 'none') + '</p>';
            showStep(5);
        });
        document.getElementById('backTo4').addEventListener('click', function () { showStep(4); });

        document.getElementById('generateBtn').addEventListener('click', function () {
            clearError();
            var btn = this;
            btn.disabled = true;
            document.getElementById('genProgress').style.display = 'flex';
            document.getElementById('genResult').style.display = 'none';

            post('generate_package', {
                modules: JSON.stringify(state.modules),
                relationships: JSON.stringify(state.relationships),
                entry_points: JSON.stringify(state.entryPoints),
                pkg_name: document.getElementById('pkgName').value,
                pkg_version: document.getElementById('pkgVersion').value,
                pkg_author: document.getElementById('pkgAuthor').value,
                pkg_description: document.getElementById('pkgDescription').value,
                pkg_key: document.getElementById('pkgKey').value,
            }).then(function (res) {
                document.getElementById('genProgress').style.display = 'none';
                btn.disabled = false;
                var resultEl = document.getElementById('genResult');
                resultEl.style.display = 'block';

                if (!res.success) {
                    resultEl.classList.add('pkgb-result-error');
                    resultEl.textContent = res.data.message;
                    return;
                }

                var warnings = [];
                (res.data.summary.modules || []).forEach(function (m) {
                    (m.warnings || []);
                });
                (res.data.summary.warnings || []).forEach(function (w) { warnings.push(w); });

                var html = '<p>Package generated: <strong>' + res.data.zip_name + '</strong> (' +
                    res.data.summary.files_copied + ' files copied)</p>' +
                    '<p><a class="pkgb-btn pkgb-btn-primary" href="' + res.data.download_url + '">Download ZIP</a></p>';

                if (warnings.length) {
                    html += '<div><strong>Warnings:</strong><ul class="pkgb-warning-list">' +
                        warnings.map(function (w) { return '<li>' + w + '</li>'; }).join('') + '</ul></div>';
                }
                resultEl.innerHTML = html;
            }).catch(function (err) {
                document.getElementById('genProgress').style.display = 'none';
                btn.disabled = false;
                showError('Request failed: ' + err);
            });
        });

        loadModules();
    }

    // ---------------------------------------------------------------
    // Custom Field Generator (field.php)
    // ---------------------------------------------------------------
    function initFieldTool() {
        var typeInfo = window.PKGB_FIELD_TYPES || {};

        function loadModules() {
            post('scan_modules', { custom_only: 'false' }).then(function (res) {
                if (!res.success) { showError(res.data.message); return; }
                var select = document.getElementById('fModule');
                select.innerHTML = '';
                res.data.modules.forEach(function (m) {
                    var opt = document.createElement('option');
                    opt.value = m.name;
                    opt.textContent = m.name + (m.is_custom ? '' : ' (stock)');
                    select.appendChild(opt);
                });
            });
        }

        function updateTypeUI() {
            var type = document.getElementById('fType').value;
            var info = typeInfo[type] || {};
            document.getElementById('lengthField').style.display = info.has_length ? '' : 'none';
            document.getElementById('relateModuleField').style.display = (type === 'relate') ? '' : 'none';
            document.getElementById('dropdownField').style.display = (type === 'enum' || type === 'multienum') ? '' : 'none';
            if (info.default_len) {
                document.getElementById('fLength').placeholder = String(info.default_len);
            }
        }

        document.getElementById('fType').addEventListener('change', updateTypeUI);
        document.getElementById('fName').addEventListener('input', function () {
            var labelField = document.getElementById('fLabel');
            if (!labelField.dataset.manuallyEdited) {
                labelField.value = this.value.replace(/_/g, ' ').replace(/\b\w/g, function (c) { return c.toUpperCase(); });
            }
        });
        document.getElementById('fLabel').addEventListener('input', function () {
            this.dataset.manuallyEdited = 'true';
        });

        document.getElementById('saveFieldBtn').addEventListener('click', function () {
            clearError();
            var name = document.getElementById('fName').value.trim().toLowerCase();
            if (!/^[a-z][a-z0-9_]*$/.test(name)) {
                showError('Field name must start with a letter and contain only lowercase letters, numbers and underscores.');
                return;
            }

            var btn = this;
            btn.disabled = true;
            document.getElementById('fieldProgress').style.display = 'flex';
            document.getElementById('fieldResult').style.display = 'none';

            post('create_field', {
                module: document.getElementById('fModule').value,
                field_name: name,
                label: document.getElementById('fLabel').value,
                type: document.getElementById('fType').value,
                length: document.getElementById('fLength').value,
                default_value: document.getElementById('fDefault').value,
                required: document.getElementById('fRequired').checked ? '1' : '',
                mass_update: document.getElementById('fMassUpdate').checked ? '1' : '',
                reportable: document.getElementById('fReportable').checked ? '1' : '',
                audited: document.getElementById('fAudited').checked ? '1' : '',
                importable: document.getElementById('fImportable').checked ? '1' : '',
                duplicate_merge: document.getElementById('fDuplicateMerge').checked ? '1' : '',
                comment: document.getElementById('fComment').value,
                help_text: document.getElementById('fHelp').value,
                relate_module: document.getElementById('fRelateModule').value,
                dropdown_name: document.getElementById('fDropdownName').value,
            }).then(function (res) {
                document.getElementById('fieldProgress').style.display = 'none';
                btn.disabled = false;
                var resultEl = document.getElementById('fieldResult');
                resultEl.style.display = 'block';
                if (!res.success) {
                    resultEl.classList.add('pkgb-result-error');
                    resultEl.textContent = res.data.message;
                    return;
                }
                resultEl.classList.remove('pkgb-result-error');
                resultEl.innerHTML = '<p>Field created.</p>' +
                    '<p>Vardef: ' + res.data.vardef_file + '</p>' +
                    '<p>Language: ' + res.data.language_file + ' (' + res.data.label_key + ')</p>' +
                    '<p>' + (res.data.repair.messages || []).join('<br>') + '</p>';
            }).catch(function (err) {
                document.getElementById('fieldProgress').style.display = 'none';
                btn.disabled = false;
                showError('Request failed: ' + err);
            });
        });

        loadModules();
        updateTypeUI();
    }

    document.addEventListener('DOMContentLoaded', function () {
        if (document.getElementById('moduleList')) {
            initWizard();
        } else if (document.getElementById('fModule')) {
            initFieldTool();
        }
    });
})();
