<?php
/**
 * ModuleScanner.php
 *
 * Detects "custom" modules (built with Module Builder / Studio, or hand-rolled)
 * as opposed to stock SuiteCRM modules, so the Package Builder UI can present
 * a checklist that defaults to custom modules only.
 *
 * Detection heuristic (in order of confidence):
 *   1. modules/<Module>/Ext exists with a *_Module_Builder.txt / module builder marker, OR
 *   2. custom/Extension/modules/<Module>/ exists (studio-managed module), OR
 *   3. the module directory is not present in the known stock module list.
 *
 * This is a heuristic, not a guarantee - stock modules that were heavily
 * customized will still be excluded by default, but can be added manually
 * via the "show all modules" toggle in the UI.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

class PkgBuilder_ModuleScanner
{
    /**
     * Stock SuiteCRM 7 CE module directory names. Not exhaustive of every
     * point-release addition, but covers the standard install so the
     * "custom only" default is accurate for the vast majority of instances.
     */
    private static $stockModules = array(
        'Accounts','aCase','aCase_Templates','Administration','AM_ProjectTemplates',
        'AM_TaskTemplates','AOBH_BusinessHours','AOK_Knowledge_Base',
        'AOK_KnowledgeBase_Categories','AOP_Case_Events','AOP_Case_Updates',
        'AOR_Charts','AOR_Conditions','AOR_Fields','AOR_Reports','AOR_Scheduled_Reports',
        'AOS_Contracts','AOS_Invoices','AOS_Line_Item_Groups','AOS_PDF_Templates',
        'AOS_Product_Categories','AOS_Products','AOS_Products_Quotes','AOS_Quotes',
        'AOW_Actions','AOW_Conditions','AOW_WorkFlow','AOW_Processed','ATT_Attachments',
        'AW_AccountRules','Bugs','Calendar','Calls','Calls_Contacts','Calls_Leads',
        'Calls_Users','Campaign_Log','Campaign_Trkrs','Campaigns','Contacts',
        'ContractTypes','Currencies','Documents','DocumentRevisions','Emails',
        'EmailAddresses','EmailMan','EmailMarketing','EmailTemplates','EAPM',
        'Employees','Events','FP_events_Contacts','FP_events_Locations',
        'FP_Event_Locations_Events','Feeds','Forecasts','FP_events_Prospects',
        'Home','Import','InboundEmail','jjwg_Maps','jjwg_Markers','jjwg_Areas',
        'jjwg_Address_Cache','KBContents','KBDocument','KBDocumentBody',
        'KBDocumentEditor','KBDocumentAttachment','KBDocumentAttachment_KBDocuments',
        'KBDocumentRevisions','Leads','Meetings','Meetings_Contacts','Meetings_Leads',
        'Meetings_Users','Notes','OAuthKeys','OAuthTokens','OutboundEmailConfiguration',
        'Opportunities','Products','ProjectResource','Project','ProjectTask',
        'ProspectLists','Prospects','pmse_Business_Rules','pmse_Inbox','pmse_Project',
        'pmse_Emails_Templates','pmse_Gateways','pmse_Inbox_Delegates',
        'pmse_Project_Related','pmse_Route_Log','SecurityGroups',
        'SecuritySuite','spots','Sync','TeamMemberships','Teams','TimePeriods',
        'Trackers','TrackerPerfs','TrackerQueries','TrackerSessions','Users',
        'UserPreferences','vCals','WorkFlow','WorkFlowActionShells','WorkFlowActions',
        'WorkFlowAlerts','WorkFlowAlertRecipients','WorkFlowTriggerShells',
        'FP_LNK','Releases','ResourceCalendar','SavedSearch','Schedulers',
        'TemplateEditor','InstantMessengers','WirelessOutboundEmailAccounts',
        'CaseUpdates','FieldsMetaData',
    );

    /**
     * @param string $basePath   SuiteCRM root path.
     * @param bool   $customOnly When true (default), only modules considered
     *                           custom are returned. When false, every
     *                           module directory is returned with an
     *                           `is_custom` flag so the UI can offer both.
     * @return array list of ['name' => module dir name, 'is_custom' => bool]
     */
    public static function scan($basePath, $customOnly = true)
    {
        $modulesDir = rtrim($basePath, '/\\') . '/modules';
        $result = array();

        if (!is_dir($modulesDir)) {
            return $result;
        }

        $entries = scandir($modulesDir);
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $fullPath = $modulesDir . '/' . $entry;
            if (!is_dir($fullPath)) {
                continue;
            }
            if (PkgBuilder_Utils::isIgnoredName($entry)) {
                continue;
            }

            $isCustom = self::isCustomModule($basePath, $entry);

            if ($customOnly && !$isCustom) {
                continue;
            }

            $result[] = array(
                'name'      => $entry,
                'is_custom' => $isCustom,
            );
        }

        usort($result, function ($a, $b) {
            return strcasecmp($a['name'], $b['name']);
        });

        return $result;
    }

    public static function isCustomModule($basePath, $moduleName)
    {
        $basePath = rtrim($basePath, '/\\');

        if (in_array($moduleName, self::$stockModules, true)) {
            // Still treat it as "custom-touched" if there's Studio/Module
            // Builder residue for it, otherwise it's stock.
            return is_dir($basePath . '/custom/Extension/modules/' . $moduleName)
                || is_dir($basePath . '/custom/modules/' . $moduleName);
        }

        // Not a recognized stock module -> treat as custom.
        return true;
    }
}
