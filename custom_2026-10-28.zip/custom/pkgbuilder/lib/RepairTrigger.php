<?php
/**
 * RepairTrigger.php
 *
 * Programmatically runs SuiteCRM's Quick Repair and Rebuild so a newly
 * generated vardef/language extension is picked up immediately, without
 * requiring the admin to click through Admin > Repair manually.
 *
 * Must be called from a context that already has a full SuiteCRM bootstrap
 * loaded (entry points that include include/entryPoint.php satisfy this).
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

class PkgBuilder_RepairTrigger
{
    /**
     * @return array ['ran' => bool, 'messages' => array]
     */
    public static function run()
    {
        $messages = array();

        if (!class_exists('RepairAndClear')) {
            $candidate = 'modules/Administration/QuickRepairAndRebuild.php';
            if (is_file($candidate)) {
                require_once $candidate;
            }
        }

        if (!class_exists('RepairAndClear')) {
            $messages[] = 'RepairAndClear class not available - please run Admin > Repair > Quick Repair and Rebuild manually.';
            return array('ran' => false, 'messages' => $messages);
        }

        try {
            $repair = new RepairAndClear();
            // Rebuild everything relevant to a new vardef/language extension:
            // extensions, vardefs, and clear the relevant caches.
            $repair->repairAndClearAll(
                array('clearAll'),
                array(translate('LBL_ALL_MODULES')),
                true,
                false
            );
            $messages[] = 'Quick Repair and Rebuild completed.';
            return array('ran' => true, 'messages' => $messages);
        } catch (Exception $e) {
            $messages[] = 'Repair failed: ' . $e->getMessage();
            return array('ran' => false, 'messages' => $messages);
        }
    }
}
