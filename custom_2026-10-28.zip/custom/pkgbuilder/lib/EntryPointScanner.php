<?php
/**
 * EntryPointScanner.php
 *
 * Scans custom/Extension/application/Ext/EntryPointRegistry/*.php for
 * registered entry points and resolves the executable PHP file each one
 * points to via its 'file' key, so both the registry snippet and the
 * referenced executable can be included in a generated package.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

class PkgBuilder_EntryPointScanner
{
    /**
     * @param string $basePath SuiteCRM root path.
     * @return array list of:
     *   [
     *     'name'          => string entry point name,
     *     'registry_file' => string relative path to the registry snippet,
     *     'target_file'   => string|null relative path to the referenced executable,
     *     'auth'          => bool|null,
     *   ]
     */
    public static function scan($basePath)
    {
        $basePath = rtrim($basePath, '/\\');
        $registryDir = $basePath . '/custom/Extension/application/Ext/EntryPointRegistry';
        $results = array();

        if (!is_dir($registryDir)) {
            return $results;
        }

        $files = glob($registryDir . '/*.php');
        if (!$files) {
            return $results;
        }

        foreach ($files as $file) {
            $contents = @file_get_contents($file);
            if ($contents === false) {
                continue;
            }

            $relativeRegistryFile = 'custom/Extension/application/Ext/EntryPointRegistry/' . basename($file);

            // Match each $entry_point_registry['Name'] = array( ... 'file' => '...', ... 'auth' => true/false ... );
            // Non-greedy capture up to the closing ");" of that specific array assignment.
            $pattern = '/\$entry_point_registry\[[\'"]([A-Za-z0-9_]+)[\'"]\]\s*=\s*array\s*\((.*?)\)\s*;/s';
            if (!preg_match_all($pattern, $contents, $matches, PREG_SET_ORDER)) {
                continue;
            }

            foreach ($matches as $match) {
                $name = $match[1];
                $body = $match[2];

                $targetFile = null;
                if (preg_match('/[\'"]file[\'"]\s*=>\s*[\'"]([^\'"]+)[\'"]/', $body, $fm)) {
                    $targetFile = $fm[1];
                }

                $auth = null;
                if (preg_match('/[\'"]auth[\'"]\s*=>\s*(true|false)/i', $body, $am)) {
                    $auth = (strtolower($am[1]) === 'true');
                }

                $results[] = array(
                    'name'          => $name,
                    'registry_file' => $relativeRegistryFile,
                    'target_file'   => $targetFile,
                    'auth'          => $auth,
                );
            }
        }

        usort($results, function ($a, $b) {
            return strcasecmp($a['name'], $b['name']);
        });

        return $results;
    }
}
