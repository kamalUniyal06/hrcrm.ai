<?php
/**
 * FieldTypes.php
 *
 * The set of vardef field types offered by the Custom Field Generator, and
 * which extra inputs (length, default, etc.) are relevant for each so the
 * UI can show/hide fields accordingly.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

class PkgBuilder_FieldTypes
{
    /**
     * type => ['label' => ..., 'has_length' => bool, 'has_default' => bool]
     */
    public static $types = array(
        'varchar'   => array('label' => 'Text (varchar)', 'has_length' => true,  'default_len' => 255),
        'text'      => array('label' => 'Text Area',       'has_length' => false, 'default_len' => null),
        'int'       => array('label' => 'Integer',         'has_length' => true,  'default_len' => 11),
        'currency'  => array('label' => 'Currency',        'has_length' => false, 'default_len' => null),
        'decimal'   => array('label' => 'Decimal',         'has_length' => true,  'default_len' => '18,2'),
        'date'      => array('label' => 'Date',            'has_length' => false, 'default_len' => null),
        'datetime'  => array('label' => 'Datetime',        'has_length' => false, 'default_len' => null),
        'bool'      => array('label' => 'Checkbox (bool)', 'has_length' => false, 'default_len' => null),
        'enum'      => array('label' => 'Dropdown (enum)', 'has_length' => false, 'default_len' => null),
        'multienum' => array('label' => 'Multi-Select (multienum)', 'has_length' => false, 'default_len' => null),
        'relate'    => array('label' => 'Relate',          'has_length' => false, 'default_len' => null),
        'id'        => array('label' => 'ID',               'has_length' => true, 'default_len' => 36),
        'email'     => array('label' => 'Email',            'has_length' => false, 'default_len' => null),
        'phone'     => array('label' => 'Phone',            'has_length' => true,  'default_len' => 100),
        'url'       => array('label' => 'URL',               'has_length' => true, 'default_len' => 255),
    );

    public static function isValidType($type)
    {
        return array_key_exists($type, self::$types);
    }
}
