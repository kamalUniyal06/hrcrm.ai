<?php
/**
 * VardefGenerator.php
 *
 * Appends a new field definition to
 *   custom/Extension/modules/<module>/Ext/Vardefs/custom_fields.php
 *
 * If the file exists, the new field definition is appended before the
 * closing PHP tag / at end of file - existing definitions are never
 * touched or removed. If the field name already exists in the file, the
 * generator refuses to add a duplicate.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

require_once 'custom/pkgbuilder/lib/FieldTypes.php';

class PkgBuilder_VardefGenerator
{
    /**
     * @param string $basePath SuiteCRM root.
     * @param string $module   Module name (bean/dictionary key style, e.g. "Accounts", "Jobs").
     * @param array  $field    Field definition, see keys pulled below.
     * @return array ['path' => relative file path, 'created' => bool, 'skipped_duplicate' => bool]
     * @throws InvalidArgumentException on invalid input.
     */
    public static function append($basePath, $module, array $field)
    {
        $name = $field['name'];
        $type = $field['type'];

        if (!PkgBuilder_Utils::isValidIdentifier($name)) {
            throw new InvalidArgumentException("Invalid field name: {$name}");
        }
        if (!PkgBuilder_Utils::isValidIdentifier($module)) {
            throw new InvalidArgumentException("Invalid module name: {$module}");
        }
        if (!PkgBuilder_FieldTypes::isValidType($type)) {
            throw new InvalidArgumentException("Invalid field type: {$type}");
        }

        $basePath = rtrim($basePath, '/\\');
        $dir = "{$basePath}/custom/Extension/modules/{$module}/Ext/Vardefs";
        $file = "{$dir}/custom_fields.php";
        $relativePath = "custom/Extension/modules/{$module}/Ext/Vardefs/custom_fields.php";

        $existingContents = '';
        $created = false;
        if (is_file($file)) {
            $existingContents = file_get_contents($file);

            // Never overwrite an existing definition for this field.
            $needle = "['fields']['{$name}']";
            if (strpos($existingContents, $needle) !== false) {
                return array('path' => $relativePath, 'created' => false, 'skipped_duplicate' => true);
            }
        } else {
            if (!is_dir($dir)) {
                if (!mkdir($dir, 0755, true) && !is_dir($dir)) {
                    throw new RuntimeException("Could not create directory: {$dir}");
                }
            }
            $created = true;
        }

        $vardef = self::buildVardefArray($field);
        $snippet = self::renderSnippet($module, $name, $vardef);

        if ($existingContents === '') {
            $out = "<?php\n";
            $out .= "/**\n * custom_fields.php\n";
            $out .= " * Custom vardef fields for module {$module}.\n";
            $out .= " * Generated/appended by Package Builder. Existing definitions are never overwritten.\n";
            $out .= " */\n\n";
            $out .= "if (!defined('sugarEntry') || !sugarEntry) {\n    die('Not a valid entry point');\n}\n\n";
            $out .= $snippet;
        } else {
            // Append before the trailing closing tag if present, else at EOF.
            $trimmed = rtrim($existingContents);
            if (substr($trimmed, -2) === '?>') {
                $trimmed = rtrim(substr($trimmed, 0, -2));
                $out = $trimmed . "\n\n" . $snippet;
            } else {
                $out = $trimmed . "\n\n" . $snippet;
            }
        }

        if (file_put_contents($file, $out) === false) {
            throw new RuntimeException("Could not write file: {$file}");
        }

        return array('path' => $relativePath, 'created' => $created, 'skipped_duplicate' => false);
    }

    /**
     * Builds the vardef definition array (before rendering to PHP source),
     * applying type-appropriate defaults per FieldTypes::$types.
     */
    private static function buildVardefArray(array $field)
    {
        $name = $field['name'];
        $type = $field['type'];
        $typeInfo = PkgBuilder_FieldTypes::$types[$type];

        $vardef = array(
            'name'  => $name,
            'vname' => 'LBL_' . strtoupper($name),
            'type'  => $type,
        );

        if (!empty($field['len']) && $typeInfo['has_length']) {
            $vardef['len'] = is_numeric($field['len']) ? (int) $field['len'] : $field['len'];
        } elseif ($typeInfo['has_length'] && $typeInfo['default_len'] !== null) {
            $vardef['len'] = $typeInfo['default_len'];
        }

        if (isset($field['default']) && $field['default'] !== '') {
            $vardef['default'] = $field['default'];
        }

        $vardef['required']        = !empty($field['required']);
        $vardef['massupdate']      = !empty($field['mass_update']);
        $vardef['reportable']      = !empty($field['reportable']);
        $vardef['audited']         = !empty($field['audited']);
        $vardef['importable']      = !empty($field['importable']) ? 'true' : 'false';
        $vardef['duplicate_merge'] = !empty($field['duplicate_merge']) ? 'enabled' : 'disabled';

        if (!empty($field['comment'])) {
            $vardef['comment'] = $field['comment'];
        }
        if (!empty($field['help'])) {
            $vardef['help'] = $field['help'];
        }

        if ($type === 'relate' && !empty($field['relate_module'])) {
            $vardef['module']     = $field['relate_module'];
            $vardef['id_name']    = $name . '_id';
            $vardef['rname']      = 'name';
            $vardef['source']     = 'non-db';
        }

        if (($type === 'enum' || $type === 'multienum') && !empty($field['dropdown_name'])) {
            $vardef['dom'] = $field['dropdown_name'];
        }

        return $vardef;
    }

    private static function renderSnippet($module, $name, array $vardef)
    {
        $lines = array();
        $lines[] = "\$dictionary['{$module}']['fields']['{$name}'] = array(";
        foreach ($vardef as $key => $value) {
            $lines[] = "    '{$key}' => " . self::exportValue($value) . ',';
        }
        $lines[] = ");";
        $lines[] = "";
        return implode("\n", $lines);
    }

    private static function exportValue($value)
    {
        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }
        if (is_int($value)) {
            return (string) $value;
        }
        return var_export((string) $value, true);
    }
}
