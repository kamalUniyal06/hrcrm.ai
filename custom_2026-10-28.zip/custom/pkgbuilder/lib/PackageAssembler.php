<?php
/**
 * PackageAssembler.php
 *
 * Copies every file belonging to the selected modules (core + custom
 * layers), selected relationship metadata, and selected entry points
 * (registry snippet + referenced executable) into a build directory shaped
 * like a Module Loader package root:
 *
 *   <build>/manifest.php
 *   <build>/modules/<Module>/...
 *   <build>/custom/modules/<Module>/...
 *   <build>/custom/Extension/modules/<Module>/...
 *   <build>/custom/metadata/<relationship>MetaData.php
 *   <build>/custom/Extension/application/Ext/EntryPointRegistry/<file>.php
 *   <build>/<referenced entry point executable, same relative path>
 *   <build>/README.md
 *
 * "Automatic detection" of vardefs / layoutdefs / language / logic hooks /
 * views / metadata / js / css / clients is implicit: those all live inside
 * custom/modules/<Module>/** or custom/Extension/modules/<Module>/**, which
 * this assembler copies in full via PkgBuilder_Utils::recursiveCopy(). The
 * per-subpath list below is used only to report what was found, for the
 * progress/summary UI.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

require_once 'custom/pkgbuilder/lib/Utils.php';

class PkgBuilder_PackageAssembler
{
    /** Subpaths checked purely for the human-readable "what was included" summary. */
    private static $reportSubpaths = array(
        'Vardefs'    => 'custom/Extension/modules/%s/Ext/Vardefs',
        'LayoutDefs' => 'custom/Extension/modules/%s/Ext/Layoutdefs',
        'Language'   => 'custom/Extension/modules/%s/Ext/Language',
        'LogicHooks (legacy)' => 'custom/modules/%s/logic_hooks.php',
        'LogicHooks (Ext)'    => 'custom/modules/%s/Ext/LogicHooks',
        'Views'      => 'custom/modules/%s/views',
        'Metadata'   => 'custom/modules/%s/metadata',
        'JS'         => 'custom/modules/%s/js',
        'CSS'        => 'custom/modules/%s/css',
        'Clients'    => 'custom/modules/%s/clients',
    );

    /**
     * @param string $basePath   SuiteCRM root.
     * @param string $buildDir   Absolute path of an empty directory to assemble into.
     * @param array  $modules    Module names selected.
     * @param array  $relationships Selected relationship rows (from RelationshipScanner).
     * @param array  $entryPoints   Selected entry point rows (from EntryPointScanner).
     * @return array Summary report: ['modules' => [...], 'files_copied' => int, 'warnings' => [...]]
     */
    public static function assemble($basePath, $buildDir, array $modules, array $relationships, array $entryPoints)
    {
        $basePath = rtrim($basePath, '/\\');
        $log = array();
        $warnings = array();
        $moduleReport = array();

        foreach ($modules as $module) {
            if (!PkgBuilder_Utils::isValidIdentifier($module)) {
                $warnings[] = "Skipped invalid module name: {$module}";
                continue;
            }

            $found = array();

            // Core module tree.
            $coreSrc = "{$basePath}/modules/{$module}";
            if (is_dir($coreSrc)) {
                PkgBuilder_Utils::recursiveCopy($coreSrc, "{$buildDir}/modules/{$module}", $log);
                $found[] = 'modules/' . $module;
            } else {
                $warnings[] = "modules/{$module} not found - module may not have a core bean directory.";
            }

            // Custom module tree (custom/modules/<module>) - includes logic
            // hooks, views, metadata, js, css, clients, etc. recursively.
            $customModSrc = "{$basePath}/custom/modules/{$module}";
            if (is_dir($customModSrc)) {
                PkgBuilder_Utils::recursiveCopy($customModSrc, "{$buildDir}/custom/modules/{$module}", $log);
                $found[] = 'custom/modules/' . $module;
            }

            // Custom Extension tree (custom/Extension/modules/<module>) -
            // includes Vardefs, Layoutdefs, Language, logic hook Ext, etc.
            $extSrc = "{$basePath}/custom/Extension/modules/{$module}";
            if (is_dir($extSrc)) {
                PkgBuilder_Utils::recursiveCopy($extSrc, "{$buildDir}/custom/Extension/modules/{$module}", $log);
                $found[] = 'custom/Extension/modules/' . $module;
            }

            // Build the informational per-subpath report.
            $subReport = array();
            foreach (self::$reportSubpaths as $label => $pattern) {
                $checkPath = $basePath . '/' . sprintf($pattern, $module);
                $subReport[$label] = file_exists($checkPath);
            }

            $moduleReport[] = array(
                'module'  => $module,
                'trees'   => $found,
                'details' => $subReport,
            );
        }

        // Selected relationship metadata files.
        foreach ($relationships as $rel) {
            $relSrc = $basePath . '/' . $rel['file'];
            if (!is_file($relSrc)) {
                $warnings[] = "Relationship metadata not found: {$rel['file']}";
                continue;
            }
            $relDst = $buildDir . '/' . $rel['file'];
            PkgBuilder_Utils::recursiveCopy($relSrc, $relDst, $log);
        }

        // Selected entry points: registry snippet + referenced executable.
        foreach ($entryPoints as $ep) {
            if (!empty($ep['registry_file'])) {
                $regSrc = $basePath . '/' . $ep['registry_file'];
                if (is_file($regSrc)) {
                    PkgBuilder_Utils::recursiveCopy($regSrc, $buildDir . '/' . $ep['registry_file'], $log);
                } else {
                    $warnings[] = "Entry point registry file not found: {$ep['registry_file']}";
                }
            }
            if (!empty($ep['target_file'])) {
                // target_file is stored relative to the SuiteCRM root, e.g. custom/api/SaveLead.php
                $targetRel = ltrim($ep['target_file'], '/');
                $targetSrc = $basePath . '/' . $targetRel;
                if (is_file($targetSrc)) {
                    PkgBuilder_Utils::recursiveCopy($targetSrc, $buildDir . '/' . $targetRel, $log);
                } else {
                    $warnings[] = "Entry point '{$ep['name']}' references missing file: {$targetRel}";
                }
            }
        }

        return array(
            'modules'      => $moduleReport,
            'files_copied' => count($log),
            'warnings'     => $warnings,
        );
    }
}
