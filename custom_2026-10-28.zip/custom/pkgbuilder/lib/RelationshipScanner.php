<?php
/**
 * RelationshipScanner.php
 *
 * Scans custom/metadata/*MetaData.php for relationship definitions and
 * returns those where either side (lhs_module / rhs_module) is one of the
 * selected modules.
 *
 * Relationship metadata files declare their relationship via
 *   $dictionary['<rel_name>']['relationships']['<rel_name>'] = array(
 *       'lhs_module' => 'Jobs',
 *       'rhs_module' => 'Contacts',
 *       ...
 *   );
 *
 * Rather than including these files (which would require a full SuiteCRM
 * bootstrap and could execute arbitrary side effects), we parse them with a
 * targeted regex. This is safe and sufficient because Module
 * Builder / Studio always writes this array in the same predictable shape.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

class PkgBuilder_RelationshipScanner
{
    /**
     * @param string $basePath        SuiteCRM root path.
     * @param array  $selectedModules Module directory names selected by the user.
     * @return array list of:
     *   [
     *     'rel_name'   => string,
     *     'file'       => string relative path e.g. custom/metadata/jobs_contactsMetaData.php,
     *     'lhs_module' => string|null,
     *     'rhs_module' => string|null,
     *   ]
     */
    public static function scan($basePath, array $selectedModules)
    {
        $basePath = rtrim($basePath, '/\\');
        $metaDir = $basePath . '/custom/metadata';
        $results = array();

        if (!is_dir($metaDir)) {
            return $results;
        }

        $selectedLower = array_map('strtolower', $selectedModules);

        $files = glob($metaDir . '/*MetaData.php');
        if (!$files) {
            return $results;
        }

        foreach ($files as $file) {
            $contents = @file_get_contents($file);
            if ($contents === false) {
                continue;
            }

            $relName = null;
            if (preg_match('/\$dictionary\[[\'"]([A-Za-z0-9_]+)[\'"]\]\[[\'"]relationships[\'"]\]/', $contents, $m)) {
                $relName = $m[1];
            } else {
                // Fall back to filename (strip MetaData.php suffix).
                $relName = preg_replace('/MetaData\.php$/', '', basename($file));
            }

            $lhsModule = null;
            $rhsModule = null;
            if (preg_match('/[\'"]lhs_module[\'"]\s*=>\s*[\'"]([A-Za-z0-9_]+)[\'"]/', $contents, $m)) {
                $lhsModule = $m[1];
            }
            if (preg_match('/[\'"]rhs_module[\'"]\s*=>\s*[\'"]([A-Za-z0-9_]+)[\'"]/', $contents, $m)) {
                $rhsModule = $m[1];
            }

            $involvesSelected = false;
            if ($lhsModule !== null && in_array(strtolower($lhsModule), $selectedLower, true)) {
                $involvesSelected = true;
            }
            if ($rhsModule !== null && in_array(strtolower($rhsModule), $selectedLower, true)) {
                $involvesSelected = true;
            }

            // If we couldn't determine lhs/rhs from content, fall back to
            // matching the filename against "<module1>_<module2>" patterns.
            if (!$involvesSelected && ($lhsModule === null || $rhsModule === null)) {
                $baseName = strtolower(preg_replace('/MetaData\.php$/', '', basename($file)));
                foreach ($selectedLower as $modLower) {
                    if (strpos($baseName, $modLower) !== false) {
                        $involvesSelected = true;
                        break;
                    }
                }
            }

            if (!$involvesSelected) {
                continue;
            }

            $relativePath = 'custom/metadata/' . basename($file);

            $results[] = array(
                'rel_name'   => $relName,
                'file'       => $relativePath,
                'lhs_module' => $lhsModule,
                'rhs_module' => $rhsModule,
            );
        }

        usort($results, function ($a, $b) {
            return strcasecmp($a['rel_name'], $b['rel_name']);
        });

        return $results;
    }
}
