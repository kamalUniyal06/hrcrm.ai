<?php
/**
 * ZipBuilder.php
 *
 * Wraps an assembled build directory (containing manifest.php, modules/,
 * custom/) into a Module Loader compatible ZIP with everything at the
 * zip root (no wrapping folder), as Module Loader expects:
 *
 *   manifest.php
 *   modules/...
 *   custom/...
 *   README.md
 *
 * Requires the PHP ZipArchive extension (bundled with PHP 7.4 by default).
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

class PkgBuilder_ZipBuilder
{
    /**
     * @param string $buildDir     Directory already containing manifest.php, modules/, custom/.
     * @param string $packageName  Sanitized package name, used only for the zip filename (<name>.zip).
     * @param string $readmeContent README.md contents to write into the package.
     * @param string $outputDir    Directory to write the final zip into.
     * @return string Absolute path to the generated zip file.
     * @throws RuntimeException on failure.
     */
    public static function build($buildDir, $packageName, $readmeContent, $outputDir)
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('The PHP ZipArchive extension is required but not available.');
        }

        file_put_contents($buildDir . '/README.md', $readmeContent);

        if (!is_dir($outputDir)) {
            mkdir($outputDir, 0755, true);
        }

        $zipPath = rtrim($outputDir, '/\\') . '/' . $packageName . '.zip';
        if (file_exists($zipPath)) {
            @unlink($zipPath);
        }

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Could not create zip file at ' . $zipPath);
        }

        $rootLen = strlen(rtrim($buildDir, '/\\')) + 1;

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($buildDir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $item) {
            $localPath = substr($item->getPathname(), $rootLen);
            $localPath = str_replace('\\', '/', $localPath);

            if ($item->isDir()) {
                $zip->addEmptyDir($localPath);
            } else {
                $zip->addFile($item->getPathname(), $localPath);
            }
        }

        $zip->close();

        return $zipPath;
    }
}