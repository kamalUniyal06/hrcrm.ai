<?php
/**
 * Utils.php
 *
 * Shared helpers for Package Builder: input sanitization and a recursive
 * directory copy that preserves permissions and skips volatile/vendor paths.
 *
 * PHP 7.4 compatible.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

class PkgBuilder_Utils
{
    /**
     * Directory / file basenames that must never be included in a generated
     * package, wherever they are found while walking a module's tree.
     */
    public static $ignoreNames = array(
        'cache',
        'logs',
        'log',
        'upload',
        'uploads',
        'vendor',
        'node_modules',
        'tmp',
        '.tmp',
        '.git',
        '.svn',
        '.DS_Store',
        'Thumbs.db',
    );

    /**
     * A conservative allow-list pattern for module / package / field names.
     * Letters, numbers and underscores only, must start with a letter.
     */
    public static function isValidIdentifier($name)
    {
        if (!is_string($name) || $name === '') {
            return false;
        }
        return (bool) preg_match('/^[A-Za-z][A-Za-z0-9_]*$/', $name);
    }

    /**
     * Sanitize a package name for use as a filesystem folder / zip name.
     * Allows letters, numbers, underscore, dash. Strips everything else.
     */
    public static function sanitizePackageName($name)
    {
        $name = trim((string) $name);
        $name = preg_replace('/[^A-Za-z0-9_\-]/', '', $name);
        return substr($name, 0, 100);
    }

    /**
     * Sanitize free-text fields (author, description) - strips tags and
     * control characters, keeps it a single-line-safe PHP string literal
     * once passed through var_export()/addslashes downstream.
     */
    public static function sanitizeText($text)
    {
        $text = (string) $text;
        $text = strip_tags($text);
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $text);
        return trim($text);
    }

    /**
     * Sanitize a semantic-ish version string, e.g. "1.0.0".
     */
    public static function sanitizeVersion($version)
    {
        $version = trim((string) $version);
        if (!preg_match('/^[0-9A-Za-z.\-_]+$/', $version)) {
            return '1.0.0';
        }
        return substr($version, 0, 20);
    }

    /**
     * True if the given basename should be skipped entirely (directory or file).
     */
    public static function isIgnoredName($basename)
    {
        return in_array($basename, self::$ignoreNames, true);
    }

    /**
     * Recursively copy $src into $dst, preserving file permissions, and
     * skipping any path component that matches self::$ignoreNames.
     * Creates destination directories as needed. Merges into existing
     * destination directories rather than failing.
     *
     * @param string $src  Absolute source path (file or directory).
     * @param string $dst  Absolute destination path.
     * @param array  $log  Reference array collecting relative paths copied.
     * @return bool true on success (source missing is treated as a no-op success)
     */
    public static function recursiveCopy($src, $dst, array &$log = array())
    {
        if (!file_exists($src)) {
            // Nothing to copy is not an error - many optional dirs won't exist.
            return true;
        }

        if (is_file($src)) {
            $baseName = basename($src);
            if (self::isIgnoredName($baseName)) {
                return true;
            }
            $dstDir = dirname($dst);
            if (!is_dir($dstDir)) {
                if (!mkdir($dstDir, 0755, true) && !is_dir($dstDir)) {
                    return false;
                }
            }
            if (!copy($src, $dst)) {
                return false;
            }
            @chmod($dst, fileperms($src) & 0777);
            $log[] = $dst;
            return true;
        }

        if (is_dir($src)) {
            $baseName = basename($src);
            if (self::isIgnoredName($baseName)) {
                return true;
            }
            if (!is_dir($dst)) {
                if (!mkdir($dst, 0755, true) && !is_dir($dst)) {
                    return false;
                }
                @chmod($dst, fileperms($src) & 0777);
            }

            $items = scandir($src);
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }
                if (self::isIgnoredName($item)) {
                    continue;
                }
                $srcPath = $src . DIRECTORY_SEPARATOR . $item;
                $dstPath = $dst . DIRECTORY_SEPARATOR . $item;
                if (!self::recursiveCopy($srcPath, $dstPath, $log)) {
                    return false;
                }
            }
            return true;
        }

        return false;
    }

    /**
     * Recursively delete a directory tree. Used to clean up temp build dirs.
     */
    public static function recursiveDelete($dir)
    {
        if (!is_dir($dir) || is_link($dir)) {
            if (file_exists($dir)) {
                @unlink($dir);
            }
            return;
        }
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path) && !is_link($path)) {
                self::recursiveDelete($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }

    /**
     * Emit a JSON response and terminate. Used by AJAX endpoints.
     */
    public static function jsonResponse($data, $success = true)
    {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=UTF-8');
        }
        echo json_encode(array(
            'success' => $success,
            'data'    => $data,
        ));
        exit;
    }
}
