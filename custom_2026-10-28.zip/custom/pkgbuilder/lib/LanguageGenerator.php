<?php
/**
 * LanguageGenerator.php
 *
 * Appends an LBL_ string to
 *   custom/Extension/modules/<module>/Ext/Language/en_us.custom_lang.php
 *
 * If the file exists, appends. Never overwrites an existing label for the
 * same key.
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not a valid entry point');
}

class PkgBuilder_LanguageGenerator
{
    /**
     * @param string $basePath SuiteCRM root.
     * @param string $module   Module name.
     * @param string $fieldName e.g. "my_field"
     * @param string $label     Human label, e.g. "My Field". Auto-derived from
     *                          $fieldName if empty.
     * @return array ['path' => relative file path, 'created' => bool, 'skipped_duplicate' => bool, 'label_key' => string]
     */
    public static function append($basePath, $module, $fieldName, $label = '')
    {
        if (!PkgBuilder_Utils::isValidIdentifier($fieldName)) {
            throw new InvalidArgumentException("Invalid field name: {$fieldName}");
        }
        if (!PkgBuilder_Utils::isValidIdentifier($module)) {
            throw new InvalidArgumentException("Invalid module name: {$module}");
        }

        $labelKey = 'LBL_' . strtoupper($fieldName);

        if ($label === '' || $label === null) {
            $label = ucwords(str_replace('_', ' ', $fieldName));
        }
        $label = PkgBuilder_Utils::sanitizeText($label);

        $basePath = rtrim($basePath, '/\\');
        $dir = "{$basePath}/custom/Extension/modules/{$module}/Ext/Language";
        $file = "{$dir}/en_us.custom_lang.php";
        $relativePath = "custom/Extension/modules/{$module}/Ext/Language/en_us.custom_lang.php";

        $existingContents = '';
        $created = false;
        if (is_file($file)) {
            $existingContents = file_get_contents($file);
            $needle = "['{$labelKey}']";
            if (strpos($existingContents, $needle) !== false) {
                return array(
                    'path' => $relativePath, 'created' => false,
                    'skipped_duplicate' => true, 'label_key' => $labelKey,
                );
            }
        } else {
            if (!is_dir($dir)) {
                if (!mkdir($dir, 0755, true) && !is_dir($dir)) {
                    throw new RuntimeException("Could not create directory: {$dir}");
                }
            }
            $created = true;
        }

        $snippet = "\$mod_strings['{$labelKey}'] = " . var_export($label, true) . ";\n";

        if ($existingContents === '') {
            $out = "<?php\n";
            $out .= "/**\n * en_us.custom_lang.php\n";
            $out .= " * Custom language labels for module {$module}.\n";
            $out .= " * Generated/appended by Package Builder. Existing labels are never overwritten.\n";
            $out .= " */\n\n";
            $out .= "if (!defined('sugarEntry') || !sugarEntry) {\n    die('Not a valid entry point');\n}\n\n";
            $out .= $snippet;
        } else {
            $trimmed = rtrim($existingContents);
            if (substr($trimmed, -2) === '?>') {
                $trimmed = rtrim(substr($trimmed, 0, -2));
            }
            $out = $trimmed . "\n" . $snippet;
        }

        if (file_put_contents($file, $out) === false) {
            throw new RuntimeException("Could not write file: {$file}");
        }

        return array(
            'path' => $relativePath, 'created' => $created,
            'skipped_duplicate' => false, 'label_key' => $labelKey,
        );
    }
}
